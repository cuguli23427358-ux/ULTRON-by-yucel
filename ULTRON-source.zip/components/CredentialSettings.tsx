"use client";

import { useEffect, useRef, useState, type FormEvent } from "react";

interface KeyStatus {
  openRouter: boolean;
  groq: boolean;
  pending: boolean;
  message?: string;
}

type Mode = "save" | "export" | "import";

interface CredentialBridge {
  credentialsStatus(): Promise<KeyStatus | null>;
  updateCredentials(request: { operation: Mode; passphrase?: string; OPENROUTER_API_KEY?: string; GROQ_API_KEY?: string }): Promise<{
    ok: boolean;
    cancelled?: boolean;
    message?: string;
  }>;
  discardCredentialFile(): Promise<void>;
  onCredentialFile(callback: () => void): () => void;
}

export default function CredentialSettings({ onOpen }: { onOpen(): void }) {
  const panel = useRef<HTMLDialogElement>(null);
  const [bridge, setBridge] = useState<CredentialBridge | null>(null);
  const [status, setStatus] = useState<KeyStatus | null>(null);
  const [mode, setMode] = useState<Mode>("save");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [openRouter, setOpenRouter] = useState("");
  const [groq, setGroq] = useState("");
  const [passphrase, setPassphrase] = useState("");
  const [confirmation, setConfirmation] = useState("");

  useEffect(() => {
    const api = (window as Window & { ultronDesktop?: CredentialBridge }).ultronDesktop;
    if (!api?.credentialsStatus) return;
    let active = true;
    const refresh = async () => {
      const latest = await api.credentialsStatus();
      if (!active || !latest) return;
      setBridge(api);
      setStatus(latest);
      if (latest.pending) {
        onOpen();
        setMode("import");
        setMessage("");
        if (panel.current && !panel.current.open) panel.current.showModal();
      }
    };
    void refresh().catch(() => {});
    const unsubscribe = api.onCredentialFile(() => { void refresh().catch(() => {}); });
    return () => { active = false; unsubscribe(); };
  }, [onOpen]);

  function show() {
    onOpen();
    setMessage(status?.message ?? "");
    setMode(status?.pending ? "import" : "save");
    panel.current?.showModal();
  }

  function clearInputs() {
    setOpenRouter("");
    setGroq("");
    setPassphrase("");
    setConfirmation("");
  }

  function changeMode(next: Mode) {
    clearInputs();
    setMessage("");
    setMode(next);
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!bridge || busy) return;
    if (mode === "export" && passphrase !== confirmation) {
      setMessage("The passphrases do not match.");
      return;
    }
    setBusy(true);
    setMessage("");
    try {
      const result = await bridge.updateCredentials(mode === "save"
        ? { operation: mode, OPENROUTER_API_KEY: openRouter, GROQ_API_KEY: groq }
        : { operation: mode, passphrase });
      setMessage(result.message ?? "");
      if (result.ok) {
        clearInputs();
        setStatus(await bridge.credentialsStatus());
      }
    } catch {
      setMessage("The settings operation failed.");
    } finally {
      setBusy(false);
    }
  }

  function close() {
    clearInputs();
    if (status?.pending && bridge) {
      void bridge.discardCredentialFile().then(async () => setStatus(await bridge.credentialsStatus())).catch(() => {});
    }
  }

  return (
    <>
      {bridge && <button type="button" className="hud-btn" onClick={show}>API KEYS</button>}
      <dialog ref={panel} className="credential-panel" aria-labelledby="api-keys-title" onClose={close}
        onCancel={(event) => { if (busy) event.preventDefault(); }} onKeyDown={(event) => event.stopPropagation()}>
        <div className="credential-heading">
          <h2 id="api-keys-title">API keys</h2>
          <button type="button" disabled={busy} onClick={() => panel.current?.close()} aria-label="Close API settings">×</button>
        </div>
        <p>OpenRouter {status?.openRouter ? "configured" : "missing"} · Groq {status?.groq ? "configured" : "missing"}</p>
        <div className="credential-modes">
          {([["save", "Enter keys"], ["export", "Export .ultron"], ["import", "Import .ultron"]] as const).map(([value, label]) => (
            <button key={value} type="button" disabled={busy} aria-pressed={mode === value} onClick={() => changeMode(value)}>{label}</button>
          ))}
        </div>
        <form onSubmit={submit}>
          {mode === "save" ? (
            <>
              <p>Leave a field blank to keep its current key.</p>
              <label>OpenRouter API key<input type="password" value={openRouter} onChange={(event) => setOpenRouter(event.target.value)} maxLength={2_048} autoComplete="off" /></label>
              <label>Groq API key<input type="password" value={groq} onChange={(event) => setGroq(event.target.value)} maxLength={2_048} autoComplete="off" /></label>
            </>
          ) : (
            <>
              <p>{mode === "export" ? "Choose a passphrase you can enter on the other PC." : status?.pending ? "Enter the passphrase for the .ultron file you opened." : "Enter the passphrase, then choose the .ultron file."}</p>
              <label>Passphrase<input type="password" value={passphrase} onChange={(event) => setPassphrase(event.target.value)} required minLength={14} maxLength={256} autoComplete={mode === "export" ? "new-password" : "current-password"} /></label>
              {mode === "export" && <label>Confirm passphrase<input type="password" value={confirmation} onChange={(event) => setConfirmation(event.target.value)} required minLength={14} maxLength={256} autoComplete="new-password" /></label>}
            </>
          )}
          <button type="submit" disabled={busy}>{busy ? "Working…" : mode === "save" ? "Save keys" : mode === "export" ? "Save encrypted backup" : "Import keys"}</button>
          {message && <p role="status">{message}</p>}
        </form>
      </dialog>
    </>
  );
}
