const { app, BrowserWindow, dialog, ipcMain, Menu, Notification, powerMonitor, safeStorage, session, shell, Tray } = require("electron");
const fs = require("node:fs");
const http = require("http");
const path = require("path");
const next = require("next");
const { createAssistant } = require("./assistant.cjs");
const { createCredentials } = require("./credentials.cjs");
const { CLOUD_ROUTES, backendUrl, forwardCloud } = require("./cloud.cjs");
const { installedBackend } = require("./connectionProfile.cjs");

const isDevelopment = !app.isPackaged;
let port = Number(process.env.ULTRON_PORT || 0);
const host = "127.0.0.1";
const appRoot = path.resolve(__dirname, "..");
let mainWindow;
let server;
let tray;
let assistant;
let credentials;
let hostedBackend = null;
let pendingCredentialFile = linkedCredentialFile(process.argv);
let quitting = false;
const notifications = new Set();
const ownsInstance = app.requestSingleInstanceLock();
if (!ownsInstance) app.quit();

const { handleDesktopAction } = require("./desktopService.cjs");

async function runDesktopAction(action) {
  if (action?.type === "assistant") return assistant.execute(action.command);
  return handleDesktopAction(action);
}

function showWindow() {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

async function setupTray() {
  const icon = await app.getFileIcon(process.execPath, { size: "small" });
  tray = new Tray(icon);
  tray.setToolTip("ULTRON");
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: "Open ULTRON", click: showWindow },
    { label: "Quit ULTRON", click: () => app.quit() },
  ]));
  tray.on("double-click", showWindow);
}

function showAlert(item) {
  if (!Notification.isSupported()) return false;
  const title = item.kind === "timer" ? "ULTRON · Timer finished" : "ULTRON · Reminder";
  const notification = new Notification({ title, body: item.text });
  notifications.add(notification);
  notification.on("click", showWindow);
  notification.once("close", () => notifications.delete(notification));
  setTimeout(() => notifications.delete(notification), 300_000).unref();
  notification.show();
  return true;
}

function readLegacyNotes() {
  try {
    const desktop = app.getPath("desktop");
    const legacy = path.join(desktop, "ULTRON_Notlar.txt");
    const file = fs.existsSync(legacy) ? legacy : path.join(desktop, "ULTRON Organized", "Documents", "ULTRON_Notlar.txt");
    if (fs.statSync(file).size > 512_000) return [];
    return fs.readFileSync(file, "utf8").split(/\r?\n/)
      .map((line) => line.replace(/^\[[^\]]+\]\s*/, "").trim()).filter(Boolean);
  } catch {
    return [];
  }
}

function linkedCredentialFile(args) {
  return args.find((arg) => !arg.startsWith("-") && path.isAbsolute(arg) && /\.ultron$/i.test(arg));
}

function trustedSender(event) {
  const frame = event.senderFrame;
  return Boolean(mainWindow && !mainWindow.isDestroyed() && event.sender === mainWindow.webContents &&
    frame && frame === event.sender.mainFrame && frame.url.startsWith(`http://${host}:${port}/`));
}

async function selectCredentialFile(operation) {
  const filters = [{ name: "ULTRON encrypted backup", extensions: ["ultron"] }];
  if (operation === "export") {
    const result = await dialog.showSaveDialog(mainWindow, {
      title: "Export encrypted API keys",
      defaultPath: path.join(app.getPath("documents"), "ULTRON Keys.ultron"),
      filters,
    });
    if (result.canceled || !result.filePath) return undefined;
    if (!/\.ultron$/i.test(result.filePath)) throw new Error("Invalid .ultron backup filename");
    return result.filePath;
  }
  if (pendingCredentialFile) return pendingCredentialFile;
  const result = await dialog.showOpenDialog(mainWindow, {
    title: "Import encrypted API keys",
    properties: ["openFile"],
    filters,
  });
  const selected = result.canceled ? undefined : result.filePaths[0];
  return selected && /\.ultron$/i.test(selected) ? selected : undefined;
}

function registerCredentialHandlers() {
  ipcMain.handle("ultron:credentials-status", (event) => {
    if (hostedBackend || !trustedSender(event)) return null;
    return { ...credentials.status(), pending: Boolean(pendingCredentialFile) };
  });
  ipcMain.handle("ultron:credentials-discard-file", (event) => {
    if (!hostedBackend && trustedSender(event)) pendingCredentialFile = undefined;
  });
  ipcMain.handle("ultron:credentials-update", async (event, request) => {
    if (hostedBackend || !trustedSender(event) || !["save", "import", "export"].includes(request?.operation)) {
      return { ok: false, message: "API settings are unavailable." };
    }
    const operation = request.operation;
    const result = await credentials.perform(operation, request, () => selectCredentialFile(operation));
    if (operation === "import" && result.ok) pendingCredentialFile = undefined;
    return result;
  });
}
async function startNextServer() {
  let handle;
  server = http.createServer((request, response) => {
    const pathname = request.url?.split("?")[0];
    const cloud = pathname && CLOUD_ROUTES.get(pathname);
    if (hostedBackend && cloud && request.method === "POST") {
      void forwardCloud(request, response, hostedBackend, pathname, cloud);
      return;
    }
    if (handle) {
      void handle(request, response).catch((error) => {
        console.error("ULTRON request failed:", error.message);
        if (!response.headersSent) response.writeHead(500);
        response.end();
      });
    } else {
      response.writeHead(503).end();
    }
  });

  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(port, host, () => {
      server.off("error", reject);
      resolve();
    });
  });
  port = server.address().port;
  const nextApp = next({ dev: isDevelopment, dir: appRoot, hostname: host, port });
  await nextApp.prepare();
  handle = nextApp.getRequestHandler();
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 820,
    minWidth: 960,
    minHeight: 640,
    backgroundColor: "#02050a",
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) {
      void shell.openExternal(url).catch((error) => console.error("Could not open link:", error.message));
    }
    return { action: "deny" };
  });
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (new URL(url).origin !== `http://${host}:${port}`) event.preventDefault();
  });
  mainWindow.on("close", (event) => {
    if (quitting || !tray) return;
    event.preventDefault();
    mainWindow.webContents.send("ultron:pause-voice");
    mainWindow.hide();
  });

  mainWindow.loadURL(`http://${host}:${port}`);
}

function configurePermissions() {
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    const origin = new URL(webContents.getURL()).origin;
    const isUltronWindow = origin === `http://${host}:${port}`;
    const allowed = isUltronWindow && permission === "media";
    callback(allowed);
  });
}

app.whenReady().then(async () => {
  if (!ownsInstance) return;
  const metadata = app.isPackaged ? require("../package.json") : {};
  if (app.isPackaged) {
    try {
      hostedBackend = installedBackend(metadata, process.resourcesPath);
    } catch (error) {
      dialog.showErrorBox("ULTRON connection setup", error.message);
      app.quit();
      return;
    }
  } else if (process.env.ULTRON_BACKEND_URL) {
    hostedBackend = backendUrl(process.env.ULTRON_BACKEND_URL, { allowLocal: true });
  }
  if (hostedBackend) pendingCredentialFile = undefined;
  if (process.platform === "win32") app.setAppUserModelId("com.ultron.orb");
  const directory = path.join(app.getPath("appData"), "ULTRON");
  if (!hostedBackend) {
    credentials = createCredentials({
      directory,
      legacyPaths: [path.join(directory, "ultron.env"), path.join(app.getPath("userData"), "ultron.env")],
      safeStorage,
      bundledEnvPath: metadata.ultronBundledCredentials ? path.join(process.resourcesPath, ".env") : undefined,
    });
    await credentials.initialize();
  }
  registerCredentialHandlers();
  configurePermissions();
  assistant = createAssistant(path.join(app.getPath("appData"), "ULTRON", "assistant.json"), {
    notify: showAlert,
    legacyNotes: readLegacyNotes,
  });
  powerMonitor.on("resume", assistant.resume);
  ipcMain.handle("ultron:run-action", (event, action) => {
    if (!trustedSender(event)) return { ok: false, message: "Desktop action unavailable" };
    return runDesktopAction(action);
  });
  await startNextServer();
  createWindow();
  if (process.platform === "win32") {
    await setupTray().catch((error) => console.warn("Could not create the ULTRON tray icon:", error.message));
  }
  assistant.start();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
    else showWindow();
  });
}).catch((error) => {
  console.error("ULTRON could not start:", error);
  app.quit();
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});

app.on("second-instance", (_event, args) => {
  const file = hostedBackend ? undefined : linkedCredentialFile(args);
  if (file) pendingCredentialFile = file;
  showWindow();
  if (file && mainWindow && !mainWindow.isDestroyed()) mainWindow.webContents.send("ultron:credential-file");
});

app.on("before-quit", () => {
  quitting = true;
  assistant?.stop();
  tray?.destroy();
  tray = undefined;
  server?.close();
});
