type CredentialName = "OPENROUTER_API_KEY" | "OPENROUTER_MODEL" | "GROQ_API_KEY";

export function apiSetting(name: CredentialName): string | undefined {
  const host = process as NodeJS.Process & Record<symbol, Partial<Record<CredentialName, string>> | undefined>;
  return (host[Symbol.for("ultron.credentials")]?.[name] ?? process.env[name])?.trim();
}
