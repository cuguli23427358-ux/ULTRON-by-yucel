#!/usr/bin/env bash
set -u
umask 077

script_dir="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
report="$script_dir/ULTRON-Pi-Tani.log"
if [[ ! -w "$script_dir" ]]; then
  report="$HOME/ULTRON-Pi-Tani.log"
fi

use_sudo=false
if command -v sudo >/dev/null && [[ -t 0 ]] && sudo -v; then
  use_sudo=true
fi

section() { printf '\n=== %s ===\n' "$1"; }

{
  section 'Pi'
  date -Is
  uname -srm
  printf 'Kullanıcı: %s\n' "$(id -un)"

  section 'ULTRON servisi'
  systemctl show ultron-gateway.service --no-pager \
    -p LoadState -p ActiveState -p SubState -p Result -p ExecMainStatus \
    -p User -p WorkingDirectory -p FragmentPath -p EnvironmentFiles 2>&1

  section 'Servis kaydı'
  if [[ "$use_sudo" == true ]]; then
    sudo -n journalctl -u ultron-gateway.service -n 60 --no-pager -o short-iso 2>&1
  else
    journalctl -u ultron-gateway.service -n 60 --no-pager -o short-iso 2>&1
  fi

  section 'Yerel 8080 testi'
  if command -v ss >/dev/null; then ss -ltn 'sport = :8080' 2>&1; fi
  if command -v curl >/dev/null; then
    curl --max-time 5 -sS -w '\nHTTP %{http_code}\n' http://127.0.0.1:8080/healthz 2>&1
  fi

  section 'API ayar dosyası'
  env_file="$HOME/.config/ultron/gateway.env"
  if [[ -f "$env_file" ]]; then
    stat -c 'İzin: %a | Sahip: %U | Grup: %G' "$env_file" 2>&1
    if [[ -r "$env_file" ]]; then
      awk -F= '
        /^OPENROUTER_API_KEY=./ { router = 1 }
        /^GROQ_API_KEY=./ { groq = 1 }
        END {
          print "OpenRouter: " (router ? "var" : "eksik")
          print "Groq: " (groq ? "var" : "eksik")
        }
      ' "$env_file"
    fi
  else
    printf 'gateway.env bulunamadı.\n'
  fi

  section 'Kurulu proje'
  install_dir="$HOME/.local/share/ultron-gateway"
  found=false
  for candidate in "$install_dir"/source-* "$HOME/ultron"; do
    [[ -d "$candidate" ]] || continue
    found=true
    printf '%s\n' "$candidate"
    if [[ -f "$candidate/.next/BUILD_ID" ]]; then
      printf '  Next.js derlemesi var.\n'
    else
      printf '  Next.js derlemesi eksik.\n'
    fi
  done
  if [[ "$found" == false ]]; then printf 'ULTRON kaynak dizini bulunamadı.\n'; fi
} | sed -E \
  -e 's/sk-or-v1-[[:alnum:]_-]+/[OPENROUTER_KEY_REDACTED]/g' \
  -e 's/gsk_[[:alnum:]_-]+/[GROQ_KEY_REDACTED]/g' \
  -e 's/((OPENROUTER_API_KEY|GROQ_API_KEY)=)[^[:space:]]+/\1[REDACTED]/g' > "$report" || {
  printf 'Rapor yazılamadı: %s\n' "$report" >&2
  exit 1
}

printf '\nRapor hazır: %s\n' "$report"
