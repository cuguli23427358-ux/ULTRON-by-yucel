// Comprehensive Desktop Actions & Automation for ULTRON

import { invitesConversation } from "./conversation";
import { parseAssistantCommand, type AssistantCommand } from "./assistantCommands";

export type DesktopAction =
  | { type: "assistant"; command: AssistantCommand }
  | { type: "launch-app"; app: string }
  | { type: "close-app"; app: string }
  | { type: "volume-up"; steps?: number }
  | { type: "volume-down"; steps?: number }
  | { type: "volume-mute" }
  | { type: "media-play-pause" }
  | { type: "media-next" }
  | { type: "media-prev" }
  | { type: "media-stop" }
  | { type: "screenshot"; openAfter?: boolean }
  | { type: "system-telemetry" }
  | { type: "lock-pc" }
  | { type: "sleep-pc" }
  | { type: "open-folder"; folder: string; path?: string }
  | { type: "organize-desktop" }
  | { type: "create-text-file"; file: string; content: string }
  | { type: "read-text-file"; file: string }
  | { type: "append-text-file"; file: string; content: string }
  | { type: "update-text-file"; file: string; revision: string; content: string }
  | { type: "search-google"; query: string }
  | { type: "search-youtube"; query: string }
  | { type: "search-wikipedia"; query: string }
  | { type: "search-github"; query: string }
  | { type: "open-url"; url: string }
  | { type: "clipboard-read" }
  | { type: "clipboard-write"; text: string }
  | { type: "clipboard-clear" }
  | { type: "save-note"; note: string }
  | { type: "draft-whatsapp-message"; contact: string; text: string }
  | { type: "open-settings"; target?: string }
  | { type: "open-whatsapp" }
  | { type: "open-steam" }
  | { type: "open-explorer" }
  | { type: "open-google" };

export type DesktopCommand = DesktopAction
  | { type: "write-document"; topic: string; file?: string }
  | { type: "revise-document"; file: string; instruction: string };

export interface DesktopActionResult {
  ok: boolean;
  message: string;
  data?: any;
  text?: string;
  revision?: string;
  filePath?: string;
  output?: string;
}

export function isDesktopApp(): boolean {
  if (typeof window === "undefined") return false;
  const bridge = (window as any).ultronDesktop;
  return Boolean(bridge?.isDesktopApp);
}

export async function executeDesktopAction(action: DesktopAction): Promise<DesktopActionResult> {
  if (typeof window === "undefined") {
    return { ok: false, message: "Desktop commands are unavailable here." };
  }

  const bridge = (window as any).ultronDesktop;
  if (bridge?.runAction) {
    try {
      return await bridge.runAction(action);
    } catch {
      return { ok: false, message: "Windows could not complete that command." };
    }
  }

  // Web Browser Fallback for compatible web actions
  switch (action.type) {
    case "search-google":
      window.open(`https://www.google.com/search?q=${encodeURIComponent(action.query)}`, "_blank");
      return { ok: true, message: `Searching Google for ${action.query}.` };
    case "search-youtube":
      window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(action.query)}`, "_blank");
      return { ok: true, message: `Searching YouTube for ${action.query}.` };
    case "search-wikipedia":
      window.open(`https://en.wikipedia.org/wiki/Special:Search?search=${encodeURIComponent(action.query)}`, "_blank");
      return { ok: true, message: `Searching Wikipedia for ${action.query}.` };
    case "search-github":
      window.open(`https://github.com/search?q=${encodeURIComponent(action.query)}`, "_blank");
      return { ok: true, message: `Searching GitHub for ${action.query}.` };
    case "open-google":
      window.open("https://www.google.com", "_blank");
      return { ok: true, message: "Google is open." };
    case "open-url":
      window.open(action.url.startsWith("http") ? action.url : `https://${action.url}`, "_blank");
      return { ok: true, message: `Link opened.` };
    default:
      return {
        ok: false,
        message: "That command requires the Windows desktop app.",
      };
  }
}

/**
 * Natural Language / Speech intent parser for desktop actions.
 * Detects Turkish and English phrasing with zero latency.
 */
function parseSearch(text: string): DesktopAction | null {
  const sites = "google|youtube|wikipedia|github";
  const first = text.match(new RegExp(`^(?:search|look\\s+up|find)\\s+(?:on\\s+)?(${sites})\\s+(?:for|about)\\s+(.+)$`, "i"));
  const last = text.match(new RegExp(`^(?:search(?:\\s+for)?|look\\s+up|find|play)\\s+(.+?)\\s+(?:on|in)\\s+(${sites})[.!?]*$`, "i"));
  const shorthand = text.match(new RegExp(`^(?:search\\s+(?:on\\s+)?)?(${sites})\\s+(?:search\\s+)?(.+)$`, "i"));
  const site = (first?.[1] ?? last?.[2] ?? shorthand?.[1])?.toLowerCase();
  const query = (first?.[2] ?? last?.[1] ?? shorthand?.[2])?.replace(/[.!?]+$/, "").trim();
  if (!query || !site) return null;
  return { type: `search-${site}` as "search-google" | "search-youtube" | "search-wikipedia" | "search-github", query };
}

function parseFileCommand(text: string): DesktopCommand | null {
  const declinesSorting = /\b(?:do not|don['’]t|never)\s+(?:organize|organise|sort|tidy|declutter|clean)\b/i.test(text);
  if (!declinesSorting && (
    /^(?:organize|organise|sort|tidy(?:\s+up)?|declutter|clean\s+up)\s+(?:(?:everything|(?:all\s+)?(?:the\s+)?files)\s+on\s+)?(?:my|the)\s+desktop\b/i.test(text) ||
    /^(?:my|the)\s+desktop\b.*?\b(?:organize|organise|sort|tidy|declutter|(?:put|group)\b.*?\binto\b.*?\bfolders)\b/i.test(text)
  )) {
    return { type: "organize-desktop" };
  }

  // A quoted name can contain spaces. In unquoted speech, the extension marks the end.
  const normalized = text.replace(/\bdot\s+(txt|text|md|markdown)\b/i, (_, ext: string) =>
    ext.toLowerCase() === "md" || ext.toLowerCase() === "markdown" ? ".md" : ".txt"
  ).replace(/\s+\.(txt|md)\b/i, ".$1");
  const file = '["“]?(.+?\\.(?:txt|md))["”]?';
  const create = normalized.match(new RegExp(`^create\\s+(?:a\\s+|an\\s+)?(?:blank\\s+|empty\\s+)?(?:text\\s+|markdown\\s+)?(?:file|document)\\s+(?:(?:called|named)\\s+)?${file}(?:\\s+(?:on\\s+(?:my|the)\\s+desktop))?(?:\\s+(with(?:\\s+the\\s+text)?|about|on)[: ]+([\\s\\S]+))?[.!?]*$`, "i"));
  if (create) {
    if (create[2] && /^(?:about|on)$/i.test(create[2])) {
      return { type: "write-document", topic: create[3].trim(), file: create[1].trim() };
    }
    return { type: "create-text-file", file: create[1].trim(), content: create[3]?.trim() ?? "" };
  }

  const write = normalized.match(/^(?:write|draft|create|generate|make)\s+(?:me\s+)?(?:an?\s+|the\s+)?(?:short\s+)?(?:article|essay|document|write[- ]?up|report|story|text(?:\s+file)?|piece|note|something)\s+(?:about|on)\s+([\s\S]+)$/i);
  if (write) {
    const named = write[1].match(new RegExp(`^([\\s\\S]+?)\\s+(?:as|called|named|and save it as)\\s+${file}[.!?]*$`, "i"));
    const topic = (named?.[1] ?? write[1]).replace(/\s+(?:and\s+save\s+it\s+)?on\s+(?:my|the)\s+desktop[.!?]*$/i, "").trim();
    return { type: "write-document", topic, file: named?.[2].trim() };
  }

  const append = normalized.match(new RegExp(`^(?:append|add)\\s+["“]([\\s\\S]+?)["”]\\s+to\\s+${file}(?:\\s+on\\s+(?:my|the)\\s+desktop)?[.!?]*$`, "i"));
  if (append) return { type: "append-text-file", content: append[1], file: append[2].trim() };

  const edit = normalized.match(new RegExp(`^(?:edit|revise|rewrite|update)\\s+${file}(?:\\s+on\\s+(?:my|the)\\s+desktop)?\\s+(?:to\\s+|and\\s+|:\\s*)([\\s\\S]+)$`, "i"));
  if (edit) return { type: "revise-document", file: edit[1].trim(), instruction: edit[2].trim() };
  return null;
}

export function parseDesktopIntent(rawText: string): DesktopCommand | null {
  const text = rawText.toLocaleLowerCase("tr-TR").trim();
  const lowerEn = rawText.toLowerCase().trim();
  if (!text) return null;
  const command = rawText.trim().replace(/^(?:(?:can|could|would)\s+you\s+)?(?:please\s+)?/i, "");
  if (invitesConversation(command)) return null;
  const assistant = parseAssistantCommand(rawText);
  if (assistant) return { type: "assistant", command: assistant };
  const special = parseSearch(command) ?? parseFileCommand(command);
  if (special) return special;

  // 1. WhatsApp Mesaj Taslağı
  const waMatch =
    rawText.match(/\b([^\s,.;]+)\s+kişisine\s+(.+?)\s+yaz(?:\\.|$)/i) ||
    rawText.match(/(?:send|write)\s+whatsapp\s+to\s+([^\s,.;]+)[:\s]+(.+)/i);
  if (waMatch) {
    return { type: "draft-whatsapp-message", contact: waMatch[1].trim(), text: waMatch[2].trim() };
  }

  // 2. Sistem Telemetrisi & Donanım Durumu
  if (
    /(sistem|işlemci|ram|cpu|bellek|pil|şarj|telemetri|donanım|bilgisayar).*(durum|nasıl|kaç|ne kadar|özellik)/.test(text) ||
    /bilgisayar.*durumu/.test(text) ||
    /(system|hardware|specs|cpu|ram|battery|telemetry|computer).*(status|specs|stats|info|diagnostic|usage|report)/i.test(lowerEn) ||
    lowerEn === "system status" ||
    lowerEn === "system specs" ||
    lowerEn === "diagnostics"
  ) {
    return { type: "system-telemetry" };
  }

  // 3. Ekran Görüntüsü (Screenshot)
  if (
    /(ekran|görüntü|screenshot).*(al|çek|kaydet)/.test(text) ||
    text === "ekran görüntüsü" ||
    text === "ekran resmi çek" ||
    /(take|capture|grab).*(screenshot|screen)/i.test(lowerEn) ||
    lowerEn === "screenshot" ||
    lowerEn === "take screenshot" ||
    lowerEn === "screen capture"
  ) {
    return { type: "screenshot", openAfter: true };
  }

  // 4. Ses Denetimi
  if (
    /sesi.*(aç|yükselt|artır|arttır|fazlalaştır|yukarı)/.test(text) ||
    text === "sesi aç" ||
    /(volume up|turn up volume|increase volume|louder)/i.test(lowerEn)
  ) {
    return { type: "volume-up", steps: 6 };
  }
  if (
    /sesi.*(kıs|azalt|düşür|aşağı)/.test(text) ||
    text === "sesi kıs" ||
    /(volume down|turn down volume|decrease volume|lower volume|quieter)/i.test(lowerEn)
  ) {
    return { type: "volume-down", steps: 6 };
  }
  if (
    /(sesi.*kapat|sessize al|sustur|mute)/.test(text) ||
    text === "sessize al" ||
    lowerEn === "mute" ||
    lowerEn === "unmute" ||
    lowerEn === "silence" ||
    /(mute audio|mute volume)/i.test(lowerEn)
  ) {
    return { type: "volume-mute" };
  }

  // 5. Medya Denetimi
  if (
    /(müziği|şarkıyı|parçayı|videoyu|medyayı).*(durdur|duraklat|dondur|beklet)/.test(text) ||
    text === "müziği durdur" ||
    text === "şarkıyı durdur" ||
    text === "duraklat" ||
    /(pause|stop).*(music|song|track|playback|video)/i.test(lowerEn) ||
    lowerEn === "pause" ||
    lowerEn === "pause music"
  ) {
    return { type: "media-play-pause" };
  }
  if (
    /(müziği|şarkıyı|parçayı|videoyu).*(oynat|başlat|devam ettir)/.test(text) ||
    text === "müziği başlat" ||
    text === "oynat" ||
    text === "devam et" ||
    /(play|resume).*(music|song|track|playback)/i.test(lowerEn) ||
    lowerEn === "play" ||
    lowerEn === "resume music"
  ) {
    return { type: "media-play-pause" };
  }
  if (
    /(sonraki|ileri|başka).*(şarkı|parça|müzik)/.test(text) ||
    text === "sonraki parça" ||
    text === "şarkıyı geç" ||
    /(next track|next song|skip song|skip track)/i.test(lowerEn) ||
    lowerEn === "next song" ||
    lowerEn === "next track"
  ) {
    return { type: "media-next" };
  }
  if (
    /(önceki|baştaki|geri).*(şarkı|parça|müzik)/.test(text) ||
    text === "önceki parça" ||
    /(previous track|previous song|last song)/i.test(lowerEn) ||
    lowerEn === "previous song"
  ) {
    return { type: "media-prev" };
  }

  // 6. Güvenlik ve Güç
  if (
    /(bilgisayarı|ekranı|oturumu).*(kilitle)/.test(text) ||
    text === "kilitle" ||
    /(lock|secure).*(pc|computer|workstation|screen)/i.test(lowerEn) ||
    lowerEn === "lock pc" ||
    lowerEn === "lock computer" ||
    lowerEn === "lock screen"
  ) {
    return { type: "lock-pc" };
  }
  if (
    /(uyku moduna|uykuya al|bilgisayarı uyut)/.test(text) ||
    /(sleep|suspend).*(pc|computer|workstation)/i.test(lowerEn) ||
    lowerEn === "sleep pc" ||
    lowerEn === "sleep"
  ) {
    return { type: "sleep-pc" };
  }

  // 7. Not Alma
  const noteMatch =
    rawText.match(/(?:şunu not al|not al|not et)[:\s]+(.+)/i) ||
    rawText.match(/(?:take a note|save note|note this down|take note)[:\s]+(.+)/i);
  if (noteMatch && noteMatch[1].trim()) {
    return { type: "save-note", note: noteMatch[1].trim() };
  }

  // 8. Pano (Clipboard)
  if (
    /(panoda ne var|panoyu oku|kopyalanan metin)/.test(text) ||
    /(read|show|check|what's on).*(clipboard)/i.test(lowerEn) ||
    lowerEn === "read clipboard"
  ) {
    return { type: "clipboard-read" };
  }
  if (
    /panoyu.*(temizle|sil)/.test(text) ||
    /(clear|empty|wipe).*(clipboard)/i.test(lowerEn) ||
    lowerEn === "clear clipboard"
  ) {
    return { type: "clipboard-clear" };
  }

  // 9. Çöp / Geri Dönüşüm
  if (
    /(çöp kutusu|geri dönüşüm).*(aç)/.test(text) ||
    /(open|show).*(recycle bin|trash)/i.test(lowerEn) ||
    lowerEn === "open recycle bin"
  ) {
    return { type: "open-folder", folder: "recycle-bin" };
  }

  // 10. Klasörler
  if (
    /(indirilenler|downloads).*(aç)/.test(text) ||
    /(open|show|access|view).*(downloads|downloads folder)/i.test(lowerEn) ||
    lowerEn === "downloads" ||
    lowerEn === "open downloads"
  ) {
    return { type: "open-folder", folder: "downloads" };
  }
  if (
    /(masaüstü|desktop).*(aç)/.test(text) ||
    /(open|show|access|view).*(desktop|desktop folder)/i.test(lowerEn) ||
    lowerEn === "desktop" ||
    lowerEn === "open desktop"
  ) {
    return { type: "open-folder", folder: "desktop" };
  }
  if (
    /(belgeler|belgelerim|documents).*(aç)/.test(text) ||
    /(open|show|access|view).*(documents|documents folder)/i.test(lowerEn) ||
    lowerEn === "documents" ||
    lowerEn === "open documents"
  ) {
    return { type: "open-folder", folder: "documents" };
  }
  if (
    /(resimler|fotoğraflar|pictures).*(aç)/.test(text) ||
    /(open|show|access|view).*(pictures|photos folder)/i.test(lowerEn) ||
    lowerEn === "pictures" ||
    lowerEn === "open pictures"
  ) {
    return { type: "open-folder", folder: "pictures" };
  }
  if (
    /(dosya gezgini|explorer|dosyalarımı).*(aç)/.test(text) ||
    /(open|launch).*(file explorer|files|explorer)/i.test(lowerEn) ||
    lowerEn === "open explorer"
  ) {
    return { type: "open-explorer" };
  }
  if (
    lowerEn === "open google" ||
    lowerEn === "google" ||
    /(google).*(aç|başlat)/.test(text) ||
    /^(open|launch|start)\s+google[.!?]*$/i.test(lowerEn)
  ) {
    return { type: "open-google" };
  }

  // 11. Web & Arama İşlemleri
  const ytMatch =
    rawText.match(/(?:youtube(?:'da|\s+üzerinde)?)\s+(.+?)\s+(?:aç|çal|dinlet|ara)/i) ||
    rawText.match(/(?:youtube(?:'da|\s+üzerinde)?)\s+(?:ara|aç|çal)\s+(.+)/i) ||
    rawText.match(/(?:search youtube for|play on youtube|youtube search)\s+(.+)/i) ||
    rawText.match(/(?:play|search)\s+(.+?)\s+on youtube/i) ||
    rawText.match(/^youtube\s+(.+)/i) ||
    rawText.match(/^search youtube\s+(.+)/i);
  if (ytMatch && ytMatch[1].trim()) {
    return { type: "search-youtube", query: ytMatch[1].trim() };
  }

  const googleMatch =
    rawText.match(/(?:google(?:'da)?)\s+(.+?)\s+ara/i) ||
    rawText.match(/(?:google(?:'da)?)\s+ara\s+(.+)/i) ||
    rawText.match(/^(?:search google for|google search|google)\s+(.+)/i);
  if (googleMatch && googleMatch[1].trim()) {
    return { type: "search-google", query: googleMatch[1].trim() };
  }

  const wikiMatch =
    rawText.match(/(?:vikipedi(?:'de)?|wikipedia(?:'da)?)\s+(.+?)\s+ara/i) ||
    rawText.match(/(?:vikipedi(?:'de)?|wikipedia(?:'da)?)\s+ara\s+(.+)/i) ||
    rawText.match(/(?:search wikipedia for|wiki search|wikipedia)\s+(.+)/i);
  if (wikiMatch && wikiMatch[1].trim()) {
    return { type: "search-wikipedia", query: wikiMatch[1].trim() };
  }

  const githubMatch =
    rawText.match(/(?:github(?:'da)?)\s+(.+?)\s+ara/i) ||
    rawText.match(/(?:github(?:'da)?)\s+ara\s+(.+)/i) ||
    rawText.match(/(?:search github for|github search)\s+(.+)/i);
  if (githubMatch && githubMatch[1].trim()) {
    return { type: "search-github", query: githubMatch[1].trim() };
  }

  // 12. Windows Ayarları
  if (
    /(ayarlar|settings).*(aç)/.test(text) ||
    /(open|launch).*(settings)/i.test(lowerEn)
  ) {
    let target = "";
    if (text.includes("wifi") || text.includes("ağ") || lowerEn.includes("wifi")) target = "wifi";
    else if (text.includes("bluetooth") || lowerEn.includes("bluetooth")) target = "bluetooth";
    else if (text.includes("ses") || lowerEn.includes("sound") || lowerEn.includes("audio")) target = "ses";
    else if (text.includes("ekran") || lowerEn.includes("display")) target = "ekran";
    else if (text.includes("güncelleme") || text.includes("update") || lowerEn.includes("update")) target = "update";
    return { type: "open-settings", target };
  }

  // 13. Evrensel Uygulama Kapatma (Universal App Close)
  const closeMatch =
    rawText.trim().match(/^(?:please\s+)?(?:close|exit|terminate|kill|shut down|quit)\s+(.+)/i) ||
    text.match(/^(.+?)\s*(?:'ı|'i|'u|'ü|i|ı|u|ü)?\s*(?:kapat|sonlandır|çık)$/i);
  if (closeMatch && closeMatch[1].trim()) {
    let rawTarget = closeMatch[1].trim().replace(/[.!?]+$/, "");
    rawTarget = rawTarget.replace(/^(the|app|application|program)\s+/i, "");
    const normalized = rawTarget.toLowerCase();
    if (normalized === "not defteri" || normalized === "notdefteri") rawTarget = "notepad";
    if (normalized === "hesap makinesi" || normalized === "hesapmakinesi" || normalized === "calc") rawTarget = "calculator";
    if (normalized === "görev yöneticisi" || normalized === "task manager") rawTarget = "taskmgr";
    return { type: "close-app", app: rawTarget };
  }

  // 14. Evrensel Uygulama Başlatma (Universal App Launch - Any Installed Program)
  const launchMatch =
    rawText.trim().match(/^(?:please\s+)?(?:open|launch|start|run)\s+(.+)/i) ||
    text.match(/^(.+?)\s*(?:'ı|'i|'u|'ü|i|ı|u|ü)?\s*(?:aç|başlat|çalıştır)$/i);
  if (launchMatch && launchMatch[1].trim()) {
    let target = launchMatch[1].trim().replace(/[.!?]+$/, "");
    target = target.replace(/^(the|app|application|program)\s+/i, "").trim();

    const lowTarget = target.toLowerCase();
    if (lowTarget === "google") return { type: "open-google" };
    if (lowTarget === "not defteri" || lowTarget === "notdefteri") return { type: "launch-app", app: "notepad" };
    if (lowTarget === "hesap makinesi" || lowTarget === "hesapmakinesi") return { type: "launch-app", app: "calculator" };
    if (lowTarget === "görev yöneticisi" || lowTarget === "task manager") return { type: "launch-app", app: "taskmgr" };

    return { type: "launch-app", app: target };
  }

  return null;
}
