let activeSpeech: AbortController | null = null;

export function stopTokSpeech(): void {
  activeSpeech?.abort();
}

function waitForPlayback(audio: HTMLAudioElement, signal: AbortSignal): Promise<boolean> {
  return new Promise((resolve) => {
    const complete = (played: boolean) => {
      clearTimeout(timer);
      signal.removeEventListener("abort", abort);
      audio.onended = null;
      audio.onerror = null;
      audio.pause();
      resolve(played);
    };
    const abort = () => complete(false);
    const timer = window.setTimeout(abort, 120_000);
    signal.addEventListener("abort", abort, { once: true });
    audio.onended = () => complete(true);
    audio.onerror = abort;
    void audio.play().catch(abort);
  });
}

function speakLocally(text: string, signal: AbortSignal): Promise<void> {
  if (!("speechSynthesis" in window)) return Promise.resolve();
  const synth = window.speechSynthesis;
  const voices = synth.getVoices().filter((voice) => /^en(?:[-_]|$)/i.test(voice.lang));
  const preferred = /guy|christopher|eric|brian|david|mark|george/i;
  const voice = voices.find((item) => preferred.test(item.name) && /natural|neural/i.test(item.name))
    ?? voices.find((item) => preferred.test(item.name))
    ?? voices.find((item) => /^en-us$/i.test(item.lang))
    ?? voices[0];
  if (!voice) return Promise.resolve();

  return new Promise((resolve) => {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = voice.lang;
    utterance.voice = voice;
    utterance.rate = 0.94;
    utterance.pitch = 0.95;
    const complete = () => {
      clearTimeout(timer);
      signal.removeEventListener("abort", abort);
      utterance.onend = null;
      utterance.onerror = null;
      resolve();
    };
    const abort = () => {
      complete();
      synth.cancel();
    };
    const timer = window.setTimeout(abort, 120_000);
    signal.addEventListener("abort", abort, { once: true });
    utterance.onend = utterance.onerror = complete;
    try {
      synth.speak(utterance);
    } catch {
      complete();
    }
  });
}

export async function speakTok(rawText: string): Promise<void> {
  stopTokSpeech();
  const text = rawText.replace(/\x60{3}[\s\S]*?\x60{3}/g, " ")
    .replace(/[*_#\x60~>]/g, "")
    .replace(/https?:\/\/\S+/gi, "the link")
    .replace(/\s+/g, " ")
    .trim().slice(0, 2000);
  if (!text) return;

  const controller = new AbortController();
  const { signal } = controller;
  activeSpeech = controller;
  try {
    let audioUrl: string | undefined;
    try {
      const response = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text }),
        signal: AbortSignal.any([signal, AbortSignal.timeout(13_000)]),
      });
      if (response.ok) {
        const audio = await response.blob();
        if (!signal.aborted && audio.size) {
          audioUrl = URL.createObjectURL(audio);
          if (await waitForPlayback(new Audio(audioUrl), signal)) return;
        }
      }
    } catch {
      // The local English voice keeps commands usable during an outage.
    } finally {
      if (audioUrl) URL.revokeObjectURL(audioUrl);
    }
    if (!signal.aborted) await speakLocally(text, signal);
  } finally {
    if (activeSpeech === controller) activeSpeech = null;
  }
}
