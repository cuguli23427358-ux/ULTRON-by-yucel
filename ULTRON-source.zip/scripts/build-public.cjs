const { spawnSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const { backendUrl } = require("../electron/cloud.cjs");
const { PROFILE_NAME, createConnectionProfile, profileHash } = require("../electron/connectionProfile.cjs");

async function main() {
  const origin = backendUrl(process.argv[2] || process.env.ULTRON_BACKEND_URL);
  const health = await fetch(origin + "/healthz", { redirect: "error", signal: AbortSignal.timeout(8_000) });
  if (!health.ok || (await health.json().catch(() => null))?.ok !== true) {
    throw new Error("The hosted ULTRON gateway is not ready at " + origin + "/healthz.");
  }

  const next = spawnSync(process.execPath, [require.resolve("next/dist/bin/next"), "build"], { stdio: "inherit" });
  if (next.status !== 0) throw next.error || new Error("Next.js build failed.");
  const { build, Platform } = require("electron-builder");
  const dist = path.resolve("dist");
  fs.mkdirSync(dist, { recursive: true });
  const staging = fs.mkdtempSync(path.join(dist, ".ultron-profile-"));
  const file = path.join(staging, PROFILE_NAME);
  try {
    const profile = createConnectionProfile(origin);
    fs.writeFileSync(file, profile);
    await build({
      targets: Platform.WINDOWS.createTarget(["nsis"]),
      config: {
        directories: { output: "dist/public" },
        extraResources: [{ from: file, to: PROFILE_NAME }],
        extraMetadata: { ultronConnectionSha256: profileHash(profile) },
        fileAssociations: [],
      },
    });
  } finally {
    if (fs.existsSync(file)) fs.unlinkSync(file);
    fs.rmdirSync(staging);
  }
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
