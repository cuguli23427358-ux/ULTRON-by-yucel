import { apiSetting } from "@/lib/apiSettings";

// Groq's free tier runs the speech model remotely, keeping Electron responsive.
export const runtime = "nodejs";

const GROQ_URL = "https://api.groq.com/openai/v1/audio/transcriptions";

export async function POST(req: Request) {
  const apiKey = apiSetting("GROQ_API_KEY");
  if (!apiKey) return Response.json({ error: "missing_key" }, { status: 503 });

  const form = await req.formData().catch(() => null);
  const audio = form?.get("audio");
  if (!(audio instanceof File) || audio.size === 0 || audio.size > 25_000_000) {
    return Response.json({ error: "bad_request" }, { status: 400 });
  }

  const upstreamForm = new FormData();
  upstreamForm.append("file", audio, "voice.webm");
  upstreamForm.append("model", "whisper-large-v3-turbo");
  upstreamForm.append("language", "en");
  upstreamForm.append("response_format", "json");

  let upstream: Response;
  try {
    upstream = await fetch(GROQ_URL, {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}` },
      body: upstreamForm,
      signal: AbortSignal.any([req.signal, AbortSignal.timeout(15_000)]),
    });
  } catch {
    return Response.json({ error: "network" }, { status: 502 });
  }
  if (!upstream.ok) {
    return Response.json({ error: "upstream", status: upstream.status }, { status: 502 });
  }

  const data = (await upstream.json().catch(() => null)) as { text?: unknown } | null;
  if (typeof data?.text !== "string") return Response.json({ error: "empty" }, { status: 502 });
  return Response.json({ text: data.text.trim() });
}
