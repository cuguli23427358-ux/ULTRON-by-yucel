#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

archive_sha='@ULTRON_ARCHIVE_SHA@'
node_version='24.22.3'
node_sha='6e51a2ada00f0011cc266f65d98922b403d7ad88f809ca2aa615a5fe1ce6e86c'
local_url='http://127.0.0.1:8080'

say() { printf '%s\n' "$*"; }
fail() { printf 'Hata: %s\n' "$*" >&2; exit 1; }
trap 'printf "Kurulum %s. satırda durdu. Üstteki hata mesajını kontrol et.\n" "$LINENO" >&2' ERR

mode="${1:-install}"
case "$mode" in
  install|--check|--tunnel-only) ;;
  *) fail 'Kullanım: bash ULTRON-Pi-Kurulum.sh [--check|--tunnel-only]' ;;
esac

work_dir="$(mktemp -d)"
cleanup() {
  rm -f -- "$work_dir/source.tar.gz" "$work_dir/node.tar.xz" "$work_dir/gateway.service" "$work_dir/tunnel.service"
  rmdir -- "$work_dir" 2>/dev/null || true
}
trap cleanup EXIT

extract_archive() {
  awk '
    /^# ULTRON_SOURCE_ARCHIVE$/ { found = 1; next }
    /^ULTRON_PAYLOAD_END$/ && found { exit }
    found { print }
  ' "$0" | base64 -d > "$work_dir/source.tar.gz"
  printf '%s  %s\n' "$archive_sha" "$work_dir/source.tar.gz" | sha256sum --check --status
}

if [[ "$mode" != --tunnel-only ]]; then
  extract_archive || fail 'Kurulum dosyası eksik veya değişmiş. Dosyayı tekrar kopyala.'
fi
if [[ "$mode" == --check ]]; then
  tar -tzf "$work_dir/source.tar.gz"
  say 'ULTRON kurulum dosyasının bütünlüğü doğrulandı.'
  exit 0
fi

[[ "$(uname -s):$(uname -m)" == Linux:aarch64 ]] || fail 'Bu dosya 64 bit Raspberry Pi OS (aarch64) içindir.'
[[ "$(id -u)" != 0 ]] || fail 'Dosyayı sudo olmadan, normal Pi kullanıcı hesabınla çalıştır.'
[[ -t 0 ]] || fail 'Dosyayı Raspberry Pi terminalinde çalıştır.'
command -v systemctl >/dev/null || fail 'systemd bulunamadı.'
command -v sudo >/dev/null || fail 'Pi kullanıcı hesabının sudo erişimi gerekiyor.'

ultron_user="$(id -un)"
install_dir="$HOME/.local/share/ultron-gateway"
config_dir="$HOME/.config/ultron"
env_file="$config_dir/gateway.env"
node_dir="$install_dir/node-v$node_version"
node_bin="$node_dir/bin/node"
npm_cli="$node_dir/lib/node_modules/npm/bin/npm-cli.js"
source_dir="$install_dir/source-${archive_sha:0:12}"

read_secret() {
  local label="$1" destination="$2" entered
  while true; do
    IFS= read -r -s -p "$label: " entered || return 1
    printf '\n'
    if [[ ${#entered} -ge 12 && ${#entered} -le 2048 && "$entered" =~ ^[-A-Za-z0-9._:+=]+$ ]]; then
      printf -v "$destination" '%s' "$entered"
      return
    fi
    say 'Anahtar boşluk içermemeli. Tekrar gir.'
  done
}

wait_for_health() {
  local origin="$1" attempt
  for attempt in {1..15}; do
    if curl -fsS --max-time 3 "$origin/healthz" 2>/dev/null | grep -Eq '"ok"[[:space:]]*:[[:space:]]*true'; then
      return
    fi
    sleep 2
  done
  return 1
}

test_chat() {
  local origin="$1" response
  if ! response="$(curl -sS --fail-with-body --max-time 45 "$origin/api/chat" \
    -H 'Content-Type: application/json' \
    -d '{"messages":[{"role":"user","content":"Say hello in one short sentence."}]}')"; then
    say "Sohbet testi yanıtı: $response"
    return 1
  fi
  grep -q '"reply"' <<< "$response"
}

install_gateway() {
  say '1/4  Raspberry Pi paketleri ve Node.js kuruluyor.'
  sudo -v
  sudo apt-get update
  sudo apt-get install -y ca-certificates curl xz-utils
  install -d -m 700 "$install_dir" "$config_dir"

  if [[ ! -x "$node_bin" ]]; then
    curl --fail --show-error --location --retry 2 \
      "https://nodejs.org/dist/v$node_version/node-v$node_version-linux-arm64.tar.xz" \
      -o "$work_dir/node.tar.xz"
    printf '%s  %s\n' "$node_sha" "$work_dir/node.tar.xz" | sha256sum --check --status ||
      fail 'Node.js arşivinin sağlama toplamı eşleşmedi.'
    tar -xJf "$work_dir/node.tar.xz" -C "$work_dir"
    [[ ! -e "$node_dir" ]] || fail "Node.js hedefi zaten var fakat kullanılamıyor: $node_dir"
    mv -- "$work_dir/node-v$node_version-linux-arm64" "$node_dir"
  fi
  export PATH="$node_dir/bin:$PATH"
  [[ "$("$node_bin" -p 'process.platform + ":" + process.arch + ":" + process.version')" == "linux:arm64:v$node_version" ]] ||
    fail 'ULTRON için kurulan Linux ARM64 Node.js doğrulanamadı.'
  [[ -f "$npm_cli" ]] || fail 'Linux npm-cli.js dosyası bulunamadı.'

  say '2/4  ULTRON projesi derleniyor.'
  if [[ ! -f "$source_dir/.next/BUILD_ID" || ! -f "$source_dir/.ultron-ready" ]]; then
    mkdir -p "$source_dir"
    tar -xzf "$work_dir/source.tar.gz" -C "$source_dir"
    (
      cd "$source_dir"
      "$node_bin" "$npm_cli" ci --no-audit --no-fund
      "$node_bin" node_modules/next/dist/bin/next build
    )
    touch "$source_dir/.ultron-ready"
  fi

  say '3/4  API ayarları ve açılış servisi hazırlanıyor.'
  if [[ -f "$env_file" ]]; then
    IFS= read -r -p 'Pi üzerindeki mevcut API ayarları kullanılsın mı? [E/h] ' keep_settings
  else
    keep_settings='h'
  fi
  if [[ -n "$keep_settings" && "$keep_settings" != "E" && "$keep_settings" != "e" ]]; then
    read_secret 'OpenRouter API anahtarı' openrouter_key
    read_secret 'Groq API anahtarı' groq_key
    local config_tmp
    config_tmp="$(mktemp "$config_dir/gateway.XXXXXX")"
    printf 'OPENROUTER_API_KEY=%s\nGROQ_API_KEY=%s\nOPENROUTER_MODEL=openai/gpt-4o-mini\n' \
      "$openrouter_key" "$groq_key" > "$config_tmp"
    unset openrouter_key groq_key
    mv -f -- "$config_tmp" "$env_file"
  fi
  chmod 600 "$env_file"
  env -u OPENROUTER_API_KEY -u GROQ_API_KEY "$node_bin" --env-file="$env_file" \
    -e 'if (!process.env.OPENROUTER_API_KEY?.trim() || !process.env.GROQ_API_KEY?.trim()) process.exit(1)' ||
    fail 'İki API anahtarı da gerekli. Dosyayı yeniden çalıştırıp ayarları değiştirebilirsin.'

  cat > "$work_dir/gateway.service" <<EOF
[Unit]
Description=ULTRON API Gateway
Wants=network-online.target
After=network-online.target

[Service]
User=$ultron_user
WorkingDirectory="$source_dir"
StateDirectory=ultron
StateDirectoryMode=0700
UMask=0077
NoNewPrivileges=true
ExecStart="$node_bin" "--env-file=$env_file" "$source_dir/scripts/gateway.cjs"
Environment=ULTRON_GATEWAY_HOST=127.0.0.1
Environment=PORT=8080
Environment=ULTRON_GATEWAY_QUOTA_FILE=/var/lib/ultron/usage.json
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
  sudo install -m 644 "$work_dir/gateway.service" /etc/systemd/system/ultron-gateway.service
  sudo systemctl daemon-reload
  sudo systemctl enable ultron-gateway.service
  sudo systemctl restart ultron-gateway.service

  say '4/4  Yerel durum ve canlı sohbet testi yapılıyor.'
  wait_for_health "$local_url" ||
    fail 'ULTRON servisi yanıt vermedi. Kayıtlar: sudo journalctl -u ultron-gateway -n 40 --no-pager'
  test_chat "$local_url" ||
    fail 'Sunucu açık ama sağlayıcı testi geçmedi. Anahtarları ve sağlayıcı limitlerini kontrol et.'
  say 'ULTRON Pi üzerinde çalışıyor. Yerel sohbet testi geçti.'
}

install_tunnel() {
  wait_for_health "$local_url" || fail 'Önce normal Pi kurulumunu tamamla.'
  say 'Cloudflare panelinde bir tünel oluştur. Published application hedefi http://127.0.0.1:8080 olmalı.'
  IFS= read -r -p 'Cloudflare tünelini şimdi bağlayalım mı? [e/H] ' wants_tunnel
  [[ "$wants_tunnel" =~ ^[Ee]$ ]] || return 0

  IFS= read -r -p 'Cloudflare hostname (örnek: ultron.seninalanadin.com): ' public_host
  [[ "$public_host" =~ ^[A-Za-z0-9]([A-Za-z0-9.-]*[A-Za-z0-9])?\.[A-Za-z]{2,}$ ]] ||
    fail 'Yalnızca alan adını yaz, başına https:// ekleme.'
  read_secret 'Cloudflare Tunnel token' tunnel_token
  sudo -v
  if ! command -v cloudflared >/dev/null; then
    sudo install -d -m 755 /usr/share/keyrings
    curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg | sudo tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null
    printf '%s\n' 'deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared any main' |
      sudo tee /etc/apt/sources.list.d/ultron-cloudflared.list >/dev/null
    sudo apt-get update
    sudo apt-get install -y cloudflared
  fi

  local cloudflared_bin
  cloudflared_bin="$(command -v cloudflared)"
  sudo install -d -m 700 /etc/ultron
  printf '%s\n' "$tunnel_token" | sudo sh -c '
    umask 077
    token_file=$(mktemp /etc/ultron/cloudflared.XXXXXX)
    cat > "$token_file" && mv -f "$token_file" /etc/ultron/cloudflared.token
  '
  unset tunnel_token

  cat > "$work_dir/tunnel.service" <<EOF
[Unit]
Description=ULTRON Cloudflare Tunnel
Wants=network-online.target
After=network-online.target ultron-gateway.service

[Service]
ExecStart="$cloudflared_bin" tunnel --no-autoupdate run --token-file /etc/ultron/cloudflared.token
NoNewPrivileges=true
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
  sudo install -m 644 "$work_dir/tunnel.service" /etc/systemd/system/ultron-tunnel.service
  sudo systemctl daemon-reload
  sudo systemctl enable ultron-tunnel.service
  sudo systemctl restart ultron-tunnel.service

  local public_url="https://$public_host"
  wait_for_health "$public_url" ||
    fail 'Yerel sunucu hazır, ancak HTTPS adresi yanıt vermedi. Cloudflare hostname ve route ayarını kontrol et.'
  test_chat "$public_url" || fail 'HTTPS sağlık testi geçti, sohbet isteği başarısız oldu.'
  say "Dışarıdan erişim ve sohbet testi geçti: $public_url"
  say "Windows yayın paketi: npm run desktop:public -- $public_url"
}

if [[ "$mode" == install ]]; then
  install_gateway
fi
install_tunnel
exit 0
