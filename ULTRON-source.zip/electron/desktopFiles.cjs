const fs = require("node:fs/promises");
const path = require("node:path");
const { createHash, randomUUID } = require("node:crypto");

const MAX_TEXT_BYTES = 24_000;
const EDITABLE_EXTENSIONS = new Set([".txt", ".md"]);
const ORGANIZE_SCRIPT = String.raw`
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$ErrorActionPreference = 'Stop'
$desktop = $env:ULTRON_DESKTOP
$root = [IO.Path]::Combine($desktop, 'ULTRON Organized')
if (Test-Path -LiteralPath $root) {
  $existing = Get-Item -LiteralPath $root -Force
  if (!$existing.PSIsContainer -or ($existing.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
    throw 'The organization folder is not a regular directory.'
  }
}
$categories = @{
  Documents = '.txt', '.md', '.pdf', '.doc', '.docx', '.rtf', '.odt', '.pages'
  Spreadsheets = '.csv', '.tsv', '.xls', '.xlsx', '.ods'
  Presentations = '.ppt', '.pptx', '.odp'
  Images = '.jpg', '.jpeg', '.png', '.gif', '.webp', '.heic', '.svg', '.bmp', '.tif', '.tiff', '.raw', '.ico'
  Videos = '.mp4', '.mov', '.mkv', '.avi', '.webm', '.m4v', '.wmv'
  Audio = '.mp3', '.wav', '.m4a', '.flac', '.ogg', '.aac'
  Archives = '.zip', '.7z', '.rar', '.tar', '.gz'
}
$moved = 0
$skipped = 0
$failed = 0
foreach ($file in (Get-ChildItem -LiteralPath $desktop -File)) {
  $category = $null
  foreach ($key in $categories.Keys) {
    if ($categories[$key] -contains $file.Extension) { $category = $key; break }
  }
  if (!$category -or $file.BaseName -match '\.before-ultron-[0-9a-f]{8}$' -or
      ($file.Attributes -band [IO.FileAttributes]::ReparsePoint)) {
    $skipped++
    continue
  }

  try {
    [void][IO.Directory]::CreateDirectory($root)
    if ([IO.File]::GetAttributes($root) -band [IO.FileAttributes]::ReparsePoint) {
      throw 'The organization folder changed.'
    }
    $folder = [IO.Path]::Combine($root, $category)
    [void][IO.Directory]::CreateDirectory($folder)
    if ([IO.File]::GetAttributes($folder) -band [IO.FileAttributes]::ReparsePoint) {
      throw 'The category folder is a reparse point.'
    }
    $destination = [IO.Path]::Combine($folder, $file.Name)
    if (Test-Path -LiteralPath $destination) {
      $skipped++
      continue
    }
    # This overload never replaces an existing file, including on a concurrent collision.
    [IO.File]::Move($file.FullName, $destination)
    $moved++
  } catch {
    $failed++
  }
}
@{ moved = $moved; skipped = $skipped; failed = $failed } | ConvertTo-Json -Compress
`;

const REPLACE_SCRIPT = String.raw`
$ErrorActionPreference = 'Stop'
$target = $env:ULTRON_TARGET
if ([IO.File]::GetAttributes($target) -band [IO.FileAttributes]::ReparsePoint) { throw 'Linked file' }
$source = [IO.File]::OpenRead($target)
$sha = [Security.Cryptography.SHA256]::Create()
try {
  $hash = [BitConverter]::ToString($sha.ComputeHash($source)).Replace('-', '')
} finally {
  $sha.Dispose()
  $source.Dispose()
}
if ($hash -ne $env:ULTRON_EXPECTED_HASH) { Write-Output 'CHANGED'; exit }
[IO.File]::Replace($env:ULTRON_REPLACEMENT, $target, $env:ULTRON_BACKUP)
Write-Output 'SAVED'
`;

class FileRequestError extends Error {}

function textPayload(value) {
  if (typeof value !== "string" || Buffer.byteLength(value, "utf8") > MAX_TEXT_BYTES || value.includes("\0")) {
    throw new FileRequestError("That text exceeds the supported file size or contains invalid characters.");
  }
  return value;
}

function validatedParts(name) {
  if (typeof name !== "string" || !name || name.length > 220) {
    throw new FileRequestError("Give me a Desktop file name ending in .txt or .md.");
  }
  const parts = name.trim().split(/[\\/]/);
  if (parts.some((part) =>
    !part || part.length > 120 || /[<>:"|?*\x00-\x1f]/.test(part) || /^[.]|[. ]$/.test(part) ||
    /^(con|prn|aux|nul|com[0-9¹²³]|lpt[0-9¹²³])(?:\.|$)/i.test(part)
  )) {
    throw new FileRequestError("Use a valid file name relative to your Desktop.");
  }
  if (!EDITABLE_EXTENSIONS.has(path.extname(parts.at(-1)).toLowerCase())) {
    throw new FileRequestError("I can create or edit .txt and .md files.");
  }
  return parts;
}

async function resolveFile(root, name, allowMissing) {
  const parts = validatedParts(name);
  let target = root;
  for (const part of parts.slice(0, -1)) {
    target = path.join(target, part);
    const info = await fs.lstat(target);
    if (!info.isDirectory() || info.isSymbolicLink()) {
      throw new FileRequestError("I can only work in regular folders on your Desktop.");
    }
  }
  target = path.join(target, parts.at(-1));
  try {
    const info = await fs.lstat(target);
    if (allowMissing) throw new FileRequestError("A file with that name already exists. Give me a new name.");
    if (!info.isFile() || info.isSymbolicLink() || info.nlink !== 1 || info.size > MAX_TEXT_BYTES) {
      throw new FileRequestError("That file is linked, too large, or not a regular text file.");
    }
  } catch (error) {
    if (!allowMissing || error.code !== "ENOENT") throw error;
  }
  return target;
}

async function readText(file) {
  const bytes = await fs.readFile(file);
  if (bytes.length > MAX_TEXT_BYTES) throw new FileRequestError("That file is too large to edit.");
  let text;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new FileRequestError("That file is not UTF-8 text.");
  }
  return { text: textPayload(text), revision: createHash("sha256").update(bytes).digest("hex"), bytes };
}

async function findEditTarget(root, file) {
  try {
    return await resolveFile(root, file, false);
  } catch (error) {
    if (error.code !== "ENOENT" || validatedParts(file).length !== 1) throw error;
    return resolveFile(root, path.join("ULTRON Organized", "Documents", file), false);
  }
}

async function writeEdit(target, original, updated, runPowerShell) {
  if (!updated.trim()) throw new FileRequestError("The revised text was empty. I kept the original.");
  if (updated === original.text) return { ok: true, message: "The file already matches that edit." };

  const folder = path.dirname(target);
  const { name, ext } = path.parse(target);
  const id = randomUUID().slice(0, 8);
  const backup = path.join(folder, `${name}.before-ultron-${id}${ext}`);
  const replacement = path.join(folder, `.ultron-${id}.tmp`);
  const hasBom = original.bytes.subarray(0, 3).equals(Buffer.from([0xef, 0xbb, 0xbf]));
  const text = original.text.includes("\r\n") ? updated.replace(/\r?\n/g, "\r\n") : updated;
  const handle = await fs.open(replacement, "wx");
  try {
    try {
      await handle.writeFile((hasBom ? "\uFEFF" : "") + text);
    } finally {
      await handle.close();
    }
    const outcome = await runPowerShell(REPLACE_SCRIPT, {
      ULTRON_TARGET: target,
      ULTRON_REPLACEMENT: replacement,
      ULTRON_BACKUP: backup,
      ULTRON_EXPECTED_HASH: original.revision,
    });
    if (outcome === "CHANGED") {
      return { ok: false, message: "The file changed while I was preparing the edit. Try again." };
    }
    if (outcome !== "SAVED") throw new Error("Unexpected file replacement result");
  } finally {
    // This path is a scratch file created exclusively by this operation.
    await fs.unlink(replacement).catch(() => {});
  }
  return {
    ok: true,
    message: `Updated ${path.basename(target)}. The original is backed up beside it as ${path.basename(backup)}.`,
    filePath: target,
  };
}

function createDesktopFileHandler(getDesktop, runPowerShell) {
  let task = Promise.resolve();

  async function run(action) {
    try {
      const root = await fs.realpath(getDesktop());
      if (action.type === "organize-desktop") {
        const { moved, skipped, failed } = JSON.parse(await runPowerShell(ORGANIZE_SCRIPT, { ULTRON_DESKTOP: root }, 120_000));
        const result = moved
          ? `Moved ${moved} ${moved === 1 ? "file" : "files"} into ULTRON Organized on your Desktop.`
          : "I did not move any Desktop files.";
        return { ok: failed === 0 || moved > 0, message: `${result} Left ${skipped + failed} in place.` };
      }

      if (action.type === "create-text-file") {
        const target = await resolveFile(root, action.file, true);
        await fs.writeFile(target, textPayload(action.content), { encoding: "utf8", flag: "wx" });
        return { ok: true, message: `Created ${action.file} on your Desktop.`, filePath: target };
      }

      const target = await findEditTarget(root, action.file);
      const original = await readText(target);
      if (action.type === "read-text-file") {
        return { ok: true, message: "File read.", text: original.text, revision: original.revision };
      }
      if (action.type === "append-text-file") {
        const addition = textPayload(action.content);
        if (!addition.trim()) throw new FileRequestError("Tell me what to append.");
        const separator = !original.text || original.text.endsWith("\n") ? "" : "\n";
        return await writeEdit(target, original, textPayload(original.text + separator + addition), runPowerShell);
      }
      if (action.revision !== original.revision) {
        return { ok: false, message: "The file changed while I was preparing the edit. Try again." };
      }
      return await writeEdit(target, original, textPayload(action.content), runPowerShell);
    } catch (error) {
      if (error instanceof FileRequestError) return { ok: false, message: error.message };
      if (error.code === "ENOENT") return { ok: false, message: "I could not find that file or folder on your Desktop." };
      if (error.code === "EEXIST") return { ok: false, message: "That name is already in use. Give me a new name." };
      console.warn("Desktop file action failed:", error.code || error.message);
      return { ok: false, message: "Windows could not finish that file operation." };
    }
  }

  return (action) => {
    const result = task.then(() => run(action));
    task = result.then(() => {}, () => {});
    return result;
  };
}

module.exports = { createDesktopFileHandler };
