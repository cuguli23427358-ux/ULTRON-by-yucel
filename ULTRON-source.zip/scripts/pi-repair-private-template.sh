#!/usr/bin/env bash
# PRIVATE: the generated copy contains live API keys. Keep it off GitHub.
set -Eeuo pipefail
umask 077

phase='Pi kontrolü'
say() { printf '%s\n' "$*"; }
show_logs() {
  sudo journalctl -u ultron-gateway.service -n 30 --no-pager >&2 || true
}
fail() {
  printf '\nHata (%s): %s\n' "$phase" "$*" >&2
  if [[ "$phase" == 'Servis başlatma' || "$phase" == 'Canlı test' ]]; then show_logs; fi
  exit 1
}
trap 'status=$?; printf "\nİşlem durdu (%s, satır %s, çıkış %s). Üstteki hatayı ve aşağıdaki kaydı paylaşabilirsin.\n" "$phase" "$LINENO" "$status" >&2; if [[ "$phase" == "Servis başlatma" || "$phase" == "Canlı test" ]]; then show_logs; fi; exit "$status"' ERR

[[ "$(uname -s):$(uname -m)" == Linux:aarch64 ]] || fail 'Bu dosyayı 64 bit Raspberry Pi OS Terminalinde çalıştır.'
[[ "$(id -u)" != 0 ]] || fail 'Bash komutunu sudo olmadan çalıştır; dosya gerektiğinde sudo isteyecek.'
for command in sudo systemctl curl; do
  command -v "$command" >/dev/null || fail "$command bulunamadı."
done

install_dir="$HOME/.local/share/ultron-gateway"
config_dir="$HOME/.config/ultron"
env_file="$config_dir/gateway.env"
node_bin="$install_dir/node-v24.22.3/bin/node"
run_user="$(id -un)"
run_group="$(id -gn)"
local_url='http://127.0.0.1:8080'

phase='Hazır derlemeyi bulma'
if [[ ! -x "$node_bin" ]]; then
  node_bin="$(command -v node || true)"
fi
[[ -n "$node_bin" && -x "$node_bin" ]] || fail 'İlk kurulumdan kalan Node.js bulunamadı.'
[[ "$("$node_bin" -p 'process.platform + ":" + process.arch')" == linux:arm64 ]] ||
  fail 'Bulunan Node.js Linux ARM64 değil.'

source_dir=''
latest_build=0
for candidate in "$install_dir"/source-* "$HOME/ultron"; do
  [[ -f "$candidate/.next/BUILD_ID" && -f "$candidate/scripts/gateway.cjs" &&
     -f "$candidate/node_modules/next/package.json" ]] || continue
  built="$(stat -c '%Y' "$candidate/.next/BUILD_ID")"
  if [[ -z "$source_dir" || "$built" -gt "$latest_build" ]]; then
    source_dir="$candidate"
    latest_build="$built"
  fi
done
[[ -n "$source_dir" ]] || fail 'Hazır ULTRON derlemesi bulunamadı. Önceki kurulumun 2/4 çıktısı gerekli.'
say "Hazır ULTRON derlemesi bulundu: $source_dir"

phase='API ayarlarını onarma'
sudo -v
work_dir="$(mktemp -d)"
trap 'rm -f -- "$work_dir/gateway.env" "$work_dir/ultron-gateway.service"; rmdir -- "$work_dir" 2>/dev/null || true' EXIT
cat > "$work_dir/gateway.env" <<'ULTRON_PRIVATE_KEYS'
OPENROUTER_API_KEY=@ULTRON_OPENROUTER_KEY@
GROQ_API_KEY=@ULTRON_GROQ_KEY@
OPENROUTER_MODEL=@ULTRON_OPENROUTER_MODEL@
ULTRON_PRIVATE_KEYS
sudo install -d -m 700 -o "$run_user" -g "$run_group" "$config_dir"
sudo install -m 600 -o "$run_user" -g "$run_group" "$work_dir/gateway.env" "$env_file"
env -u OPENROUTER_API_KEY -u GROQ_API_KEY "$node_bin" --env-file="$env_file"   -e 'if (!process.env.OPENROUTER_API_KEY || !process.env.GROQ_API_KEY) process.exit(1)' ||
  fail 'Yazılan anahtarlar Node.js tarafından okunamadı.'
say 'İki API anahtarı yazıldı ve okunabildi.'

phase='Servis başlatma'
cat > "$work_dir/ultron-gateway.service" <<EOF
[Unit]
Description=ULTRON API Gateway
Wants=network-online.target
After=network-online.target

[Service]
User=$run_user
WorkingDirectory="$source_dir"
StateDirectory=ultron
StateDirectoryMode=0700
UMask=0077
NoNewPrivileges=true
EnvironmentFile="$env_file"
Environment=NODE_ENV=production
Environment=ULTRON_GATEWAY_HOST=127.0.0.1
Environment=PORT=8080
Environment=ULTRON_GATEWAY_QUOTA_FILE=/var/lib/ultron/usage.json
ExecStart="$node_bin" "$source_dir/scripts/gateway.cjs"
Restart=on-failure
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
sudo systemd-analyze verify "$work_dir/ultron-gateway.service"
sudo install -m 644 "$work_dir/ultron-gateway.service" /etc/systemd/system/ultron-gateway.service
sudo systemctl daemon-reload
sudo systemctl enable ultron-gateway.service
sudo systemctl restart ultron-gateway.service

healthy=false
for attempt in {1..25}; do
  if sudo systemctl is-active --quiet ultron-gateway.service &&
     curl -fsS --max-time 2 "$local_url/healthz" 2>/dev/null | grep -Eq '"ok"[[:space:]]*:[[:space:]]*true'; then
    healthy=true
    break
  fi
  sleep 2
done
[[ "$healthy" == true ]] || fail 'Yerel sunucu 8080 üzerinden yanıt vermedi.'

phase='Canlı test'
if ! reply="$(curl -sS --fail-with-body --max-time 45 "$local_url/api/chat"   -H 'Content-Type: application/json'   -d '{"messages":[{"role":"user","content":"Say hello in one short sentence."}]}')"; then
  fail "Sohbet isteği başarısız. Sunucu yanıtı: $reply"
fi
grep -q '"reply"' <<< "$reply" || fail "Sohbet yanıtı alınamadı: $reply"
say 'Yerel sohbet testi geçti. ULTRON Pi üzerinde çalışıyor.'
