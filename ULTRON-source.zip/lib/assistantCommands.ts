export type AssistantCommand =
  | { operation: "timer"; text: string }
  | { operation: "remind"; text: string }
  | { operation: "schedule"; text: string }
  | { operation: "agenda"; range: string }
  | { operation: "briefing"; range: string }
  | { operation: "alerts"; range: string }
  | { operation: "cancel"; kind: "timer" | "reminder" | "event"; text: string }
  | { operation: "add-task" | "complete-task" | "add-note"; text: string }
  | { operation: "tasks" }
  | { operation: "notes"; text?: string };

export interface ResearchSource {
  title: string;
  url: string;
}

const DAY = "today|tomorrow|this week|next week|upcoming|(?:next )?(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday)";

function dayFromEnd(text: string, fallback: string): string {
  return text.match(new RegExp(`\\b(${DAY})$`, "i"))?.[1].toLowerCase() ?? fallback;
}

export function parseAssistantCommand(raw: string): AssistantCommand | null {
  const command = raw.trim().replace(/^(?:(?:can|could|would)\s+you\s+)?(?:please\s+)?/i, "");
  const text = command.replace(/’/g, "'").replace(/[.!?]+$/, "");
  const reminder = text.match(/^remind me\s+([\s\S]+)$/i);
  if (reminder) return { operation: "remind", text: reminder[1] };

  const timer = text.match(/^(?:set|start)\s+(?:a\s+)?timer(?:\s+for)?\s+(.+)$/i);
  if (timer) return { operation: "timer", text: timer[1] };
  const namedTimer = text.match(/^(?:set|start)\s+(?:a\s+)?(.+?)\s+timer(?:\s+(.*))?$/i);
  if (namedTimer) return { operation: "timer", text: [namedTimer[1], namedTimer[2]].filter(Boolean).join(" ") };

  const schedule = text.match(/^(?:schedule|add (?:a |an )?(?:calendar )?event(?: called)?|add to my calendar:?|put on my calendar:?)\s+([\s\S]+)$/i)
    ?? text.match(/^(?:add|put)\s+(.+?)\s+(?:to|on)\s+my calendar$/i);
  if (schedule) return { operation: "schedule", text: schedule[1].trim() };

  const cancel = text.match(/^(?:cancel|remove)\s+(?:(?:the|my)\s+)?(timer|reminder|event)(?:\s+(?:called\s+|for\s+)?(.*))?$/i);
  if (cancel) return { operation: "cancel", kind: cancel[1].toLowerCase() as "timer" | "reminder" | "event", text: cancel[2] ?? "" };

  if (/^(?:(?:give|show|read) me (?:my |the )?)?(?:morning |daily )?briefing(?: for .+)?$/i.test(text)) {
    return { operation: "briefing", range: dayFromEnd(text, "today") };
  }
  if (/^(?:agenda|calendar|schedule)$|^(?:(?:show|read) (?:me )?(?:my |the )?|what(?:'s| is) on (?:my |the )?|what do i have (?:on |scheduled )?)(?:agenda|calendar|schedule|today|tomorrow)(?:\s+.*)?$|^(?:show|list) (?:my )?(?:calendar )?events(?:\s+.*)?$/i.test(text)) {
    return { operation: "agenda", range: dayFromEnd(text, "today") };
  }
  if (/^(?:(?:show|list|read) (?:me )?(?:my |the )?|what (?:are|about) (?:my |the )?)?(?:active |upcoming )?(?:reminders|timers|alerts)(?:\s+.*)?$/i.test(text)) {
    return { operation: "alerts", range: dayFromEnd(text, "upcoming") };
  }

  const added = text.match(/^(?:add\s+(.+?)\s+to (?:my |the )?(?:to[- ]?do(?: list)?|task list|list)|add (?:a )?(?:task|to[- ]?do)[: ]+(.+))$/i);
  if (added) return { operation: "add-task", text: (added[1] ?? added[2]).trim() };
  const done = text.match(/^(?:mark\s+(.+?)\s+(?:as\s+)?(?:done|complete|completed)|complete (?:the task\s+)?(.+))$/i);
  if (done) return { operation: "complete-task", text: (done[1] ?? done[2]).trim() };
  if (/^what(?:'s| is) left(?: on my list)?$|^(?:(?:show|list|read) (?:me )?(?:my |the )?)?(?:tasks|to[- ]?dos|to[- ]?do list|task list)$/i.test(text)) {
    return { operation: "tasks" };
  }

  const note = command.match(/^(?:take (?:a )?note|save (?:a )?note|add (?:a )?note|note this down)[:\s]+([\s\S]+)$/i);
  if (note) return { operation: "add-note", text: note[1].trim() };
  const notesQuery = text.match(/^(?:find|search) (?:my )?notes (?:for|about|on) (.+)$/i);
  if (notesQuery) return { operation: "notes", text: notesQuery[1] };
  if (/^(?:(?:show|list|read) (?:me )?(?:my |the )?)?(?:recent )?notes$/i.test(text)) return { operation: "notes" };
  return null;
}

export function assistantDateFollowUp(raw: string): string | null {
  const match = raw.trim().match(new RegExp(`^(?:and|what about|how about)\\s+(${DAY})[.!?]*$`, "i"));
  return match?.[1].toLowerCase() ?? null;
}

export function researchQuestion(raw: string): string | null {
  const text = raw.trim().replace(/’/g, "'").replace(/^(?:(?:can|could|would) you\s+)?(?:please\s+)?/i, "");
  const explicit = text.match(/^(?:research|search the web for|look up online|look up on the web|find (?:out |online )?(?:about )?)\s+(.+)$/i);
  if (explicit) return explicit[1];
  if (/^(?:what(?:'s| is| are| happened| were)|who(?:'s| is| won)|how (?:much|many|did)|give me|tell me|summarize)\b.*\b(?:today|latest|recent|this week|right now|current|breaking news|live|yesterday)\b/i.test(text)) {
    return text;
  }
  return null;
}
