const fs = require("node:fs/promises");
const path = require("node:path");
const { createCipheriv, createDecipheriv, randomBytes, randomUUID, scrypt } = require("node:crypto");
const { promisify, parseEnv } = require("node:util");

const CREDENTIAL_NAMES = ["OPENROUTER_API_KEY", "OPENROUTER_MODEL", "GROQ_API_KEY"];
const runtime = Symbol.for("ultron.credentials");
const FILE_MAGIC = Buffer.from("ULTRON\0\x01", "ascii");
const SALT_LENGTH = 16;
const IV_LENGTH = 12;
const TAG_LENGTH = 16;
const HEADER_LENGTH = FILE_MAGIC.length + SALT_LENGTH + IV_LENGTH;
const MAX_FILE_LENGTH = 32_768;
const deriveKey = promisify(scrypt);

class CredentialError extends Error {}

function readSettings(value) {
  const result = {};
  for (const name of CREDENTIAL_NAMES) {
    const text = typeof value?.[name] === "string" ? value[name].trim() : "";
    if (text && text.length <= 2_048 && !/[\x00-\x20\x7f]/.test(text)) result[name] = text;
  }
  return result;
}

function hasKey(settings) {
  return Boolean(settings.OPENROUTER_API_KEY || settings.GROQ_API_KEY);
}

function checkPassphrase(passphrase) {
  if (typeof passphrase !== "string" || [...passphrase.trim()].length < 14 || passphrase.length > 256) {
    throw new CredentialError("Choose a passphrase of 14 to 256 characters.");
  }
}

async function keyFor(passphrase, salt) {
  return deriveKey(passphrase, salt, 32, { N: 131072, r: 8, p: 1, maxmem: 256 * 1024 * 1024 });
}

async function seal(settings, passphrase) {
  checkPassphrase(passphrase);
  settings = readSettings(settings);
  if (!hasKey(settings)) throw new CredentialError("Save an API key before exporting.");
  const salt = randomBytes(SALT_LENGTH);
  const iv = randomBytes(IV_LENGTH);
  const header = Buffer.concat([FILE_MAGIC, salt, iv]);
  const key = await keyFor(passphrase, salt);
  try {
    const cipher = createCipheriv("aes-256-gcm", key, iv, { authTagLength: TAG_LENGTH });
    cipher.setAAD(header);
    const ciphertext = Buffer.concat([cipher.update(JSON.stringify(settings), "utf8"), cipher.final()]);
    return Buffer.concat([header, cipher.getAuthTag(), ciphertext]);
  } finally {
    key.fill(0);
  }
}

async function unseal(file, passphrase) {
  checkPassphrase(passphrase);
  if (file.length <= HEADER_LENGTH + TAG_LENGTH || file.length > MAX_FILE_LENGTH ||
      !file.subarray(0, FILE_MAGIC.length).equals(FILE_MAGIC)) {
    throw new CredentialError("That file is not a supported .ultron backup.");
  }
  const header = file.subarray(0, HEADER_LENGTH);
  const salt = header.subarray(FILE_MAGIC.length, FILE_MAGIC.length + SALT_LENGTH);
  const iv = header.subarray(FILE_MAGIC.length + SALT_LENGTH);
  const key = await keyFor(passphrase, salt);
  try {
    const decipher = createDecipheriv("aes-256-gcm", key, iv, { authTagLength: TAG_LENGTH });
    decipher.setAAD(header);
    decipher.setAuthTag(file.subarray(HEADER_LENGTH, HEADER_LENGTH + TAG_LENGTH));
    const plaintext = Buffer.concat([decipher.update(file.subarray(HEADER_LENGTH + TAG_LENGTH)), decipher.final()]);
    try {
      const settings = readSettings(JSON.parse(plaintext.toString("utf8")));
      if (!hasKey(settings)) throw new Error("No API credentials");
      return settings;
    } finally {
      plaintext.fill(0);
    }
  } catch {
    throw new CredentialError("Could not unlock the backup. Check the passphrase and file.");
  } finally {
    key.fill(0);
  }
}

async function readBounded(file) {
  const handle = await fs.open(file, "r");
  try {
    const { size } = await handle.stat();
    if (size < 1 || size > MAX_FILE_LENGTH) throw new CredentialError("That settings file has an invalid size.");
    const bytes = Buffer.alloc(size);
    const { bytesRead } = await handle.read(bytes, 0, size, 0);
    if (bytesRead !== size || (await handle.stat()).size !== size) {
      throw new CredentialError("The settings file changed while it was being read.");
    }
    return bytes;
  } finally {
    await handle.close();
  }
}

async function writeAtomic(file, data) {
  const temporary = path.join(path.dirname(file), `.ultron-${randomUUID()}.tmp`);
  const handle = await fs.open(temporary, "wx", 0o600);
  try {
    try {
      await handle.writeFile(data);
      await handle.sync();
    } finally {
      await handle.close();
    }
    await fs.rename(temporary, file);
  } finally {
    await fs.unlink(temporary).catch(() => {});
  }
}

function createCredentials({ directory, legacyPaths, safeStorage, bundledEnvPath }) {
  const protectedFile = path.join(directory, "credentials.bin");
  let bundled = {};
  let current = {};
  let busy = false;
  let startupMessage;

  function publish(settings) {
    current = settings;
    process[runtime] = Object.freeze({ ...bundled, ...current });
  }

  function snapshot() {
    return { ...readSettings(process.env), ...bundled, ...current };
  }

  async function available() {
    if (!await safeStorage.isAsyncEncryptionAvailable() ||
        (process.platform === "linux" && safeStorage.getSelectedStorageBackend() === "basic_text")) {
      throw new CredentialError("Windows protected storage is unavailable.");
    }
  }

  async function persist(settings) {
    await available();
    await fs.mkdir(directory, { recursive: true });
    await writeAtomic(protectedFile, await safeStorage.encryptStringAsync(JSON.stringify(settings)));
    publish(settings);
  }

  async function initialize() {
    if (bundledEnvPath) {
      const raw = await readBounded(bundledEnvPath);
      bundled = readSettings(parseEnv(raw.toString("utf8")));
      if (!bundled.OPENROUTER_API_KEY || !bundled.GROQ_API_KEY) {
        throw new CredentialError("The installer is missing its bundled API keys.");
      }
    }
    publish({});

    let protectedData;
    try {
      protectedData = await readBounded(protectedFile);
    } catch (error) {
      if (error.code !== "ENOENT") {
        startupMessage = "Could not read the protected API keys. Import a backup or enter your keys.";
        return;
      }
    }
    if (protectedData) {
      try {
        await available();
        const decrypted = await safeStorage.decryptStringAsync(protectedData);
        const settings = readSettings(JSON.parse(decrypted.result));
        publish(settings);
        if (decrypted.shouldReEncrypt) {
          await persist(settings).catch(() => { startupMessage = "Your API keys could not be re-protected."; });
        }
      } catch {
        startupMessage = "Could not unlock the protected API keys. Import a backup or enter your keys.";
      }
      return;
    }

    for (const legacy of legacyPaths) {
      try {
        const raw = await readBounded(legacy);
        const settings = readSettings(parseEnv(raw.toString("utf8")));
        if (!hasKey(settings)) continue;
        publish(settings);
        try {
          await persist(settings);
          startupMessage = "Existing keys were copied to protected storage. Keep the old settings file private.";
        } catch {
          startupMessage = "Your previous keys are usable, but Windows could not save a protected copy.";
        }
        return;
      } catch {
        // Look for the earlier profile location if this file is missing or invalid.
      }
    }
  }

  function status() {
    const settings = snapshot();
    return {
      openRouter: Boolean(settings.OPENROUTER_API_KEY),
      groq: Boolean(settings.GROQ_API_KEY),
      message: startupMessage,
    };
  }

  async function perform(operation, parameters, chooseFile) {
    if (busy) return { ok: false, message: "Another settings operation is in progress." };
    busy = true;
    try {
      if (operation === "save") {
        const supplied = readSettings(parameters);
        if (!hasKey(supplied)) throw new CredentialError("Enter at least one valid API key.");
        await persist({ ...snapshot(), ...supplied });
        startupMessage = undefined;
        return { ok: true, message: "API keys saved in protected storage." };
      }
      const passphrase = parameters?.passphrase;
      checkPassphrase(passphrase);
      if (operation === "export") {
        const settings = snapshot();
        if (!hasKey(settings)) throw new CredentialError("Save an API key before exporting.");
        const file = await chooseFile();
        if (!file) return { ok: false, cancelled: true };
        await writeAtomic(file, await seal(settings, passphrase));
        return { ok: true, message: "Encrypted .ultron backup saved." };
      }
      if (operation === "import") {
        const file = await chooseFile();
        if (!file) return { ok: false, cancelled: true };
        const settings = await unseal(await readBounded(file), passphrase);
        await persist({ ...snapshot(), ...settings });
        startupMessage = undefined;
        return { ok: true, message: "API keys imported and ready to use." };
      }
      throw new CredentialError("Unknown settings operation.");
    } catch (error) {
      return { ok: false, message: error instanceof CredentialError ? error.message : "Windows could not finish that settings operation." };
    } finally {
      busy = false;
    }
  }

  return { initialize, status, perform };
}

module.exports = { createCredentials, seal, unseal };
