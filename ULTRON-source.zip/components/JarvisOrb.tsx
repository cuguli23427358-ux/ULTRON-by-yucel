"use client";

import { useCallback, useEffect, useRef, useState, type FormEvent } from "react";
import { createOrbScene, type OrbSceneApi } from "@/lib/orbScene";
import { HandTracker, type TrackerStatus } from "@/lib/handTracker";
import { VoiceAgent, type VoiceState } from "@/lib/voiceAgent";
import type { ResearchSource } from "@/lib/assistantCommands";
import CredentialSettings from "./CredentialSettings";

type CameraState = "off" | "starting" | "on" | "error";

const MODE_LABEL: Record<TrackerStatus["mode"], string> = {
  idle: "STANDBY",
  spin: "SPIN",
  zoom: "ZOOM",
};

const VOICE_BUTTON_LABEL: Record<VoiceState, string> = {
  off: "VOICE OFF",
  listening: "LISTENING",
  thinking: "THINKING…",
  speaking: "SPEAKING",
};

const VOICE_STATUS_LABEL: Record<VoiceState, string> = {
  off: "",
  listening: "LISTENING…",
  thinking: "PROCESSING…",
  speaking: "SPEAKING",
};

export default function JarvisOrb() {
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const overlayRef = useRef<HTMLCanvasElement>(null);
  const sceneRef = useRef<OrbSceneApi | null>(null);
  const trackerRef = useRef<HandTracker | null>(null);
  const voiceRef = useRef<VoiceAgent | null>(null);

  const [camera, setCamera] = useState<CameraState>("off");
  const [status, setStatus] = useState<TrackerStatus>({ hands: 0, mode: "idle" });
  const [error, setError] = useState<string | null>(null);

  const [voice, setVoice] = useState<VoiceState>("off");
  const [userText, setUserText] = useState("");
  const [replyText, setReplyText] = useState("");
  const [sources, setSources] = useState<ResearchSource[]>([]);
  const [voiceError, setVoiceError] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const pauseForSettings = useCallback(() => voiceRef.current?.stop(), []);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;
    const scene = createOrbScene(container);
    sceneRef.current = scene;
    return () => {
      trackerRef.current?.stop();
      trackerRef.current = null;
      scene.dispose();
      sceneRef.current = null;
    };
  }, []);

  // Voice conversation (OpenRouter via /api/chat)
  useEffect(() => {
    const agent = new VoiceAgent(
      {
        onState: (s) => {
          setVoice(s);
          sceneRef.current?.setActivity(s === "off" ? "idle" : s);
        },
        onUserText: (text, final) => {
          setUserText(text);
          if (final) setReplyText("");
        },
        onReply: setReplyText,
        onSources: setSources,
        onError: setVoiceError,
      },
    );
    voiceRef.current = agent;
    return () => {
      agent.stop();
      voiceRef.current = null;
    };
  }, []);

  // Error messages fade away on their own
  useEffect(() => {
    if (!voiceError) return;
    const id = window.setTimeout(() => setVoiceError(null), 8000);
    return () => window.clearTimeout(id);
  }, [voiceError]);

  const toggleVoice = useCallback(() => {
    const agent = voiceRef.current;
    if (!agent) return;
    setVoiceError(null);
    if (agent.getState() === "off") {
      setUserText("");
      setReplyText("");
      setSources([]);
      agent.start();
    } else {
      agent.stop();
    }
  }, []);

  const submitDraft = useCallback(
    (e: FormEvent) => {
      e.preventDefault();
      const text = draft.trim();
      if (!text) return;
      setDraft("");
      setVoiceError(null);
      voiceRef.current?.sendText(text);
    },
    [draft],
  );

  const stopGestures = useCallback(() => {
    trackerRef.current?.stop();
    trackerRef.current = null;
    setCamera("off");
    setStatus({ hands: 0, mode: "idle" });
  }, []);

  useEffect(() => {
    const bridge = (window as Window & { ultronDesktop?: {
      onPauseVoice?: (callback: () => void) => () => void;
    } }).ultronDesktop;
    return bridge?.onPauseVoice?.(() => {
      voiceRef.current?.stop();
      stopGestures();
    });
  }, [stopGestures]);

  const startGestures = useCallback(async () => {
    const video = videoRef.current;
    const overlay = overlayRef.current;
    if (!video || !overlay || trackerRef.current) return;

    setCamera("starting");
    setError(null);

    const tracker = new HandTracker(video, overlay, {
      onRotate: (dt, dp) => sceneRef.current?.rotateBy(dt, dp),
      onZoom: (factor) => sceneRef.current?.zoomBy(factor),
      onStatus: setStatus,
    });
    trackerRef.current = tracker;

    try {
      await tracker.start();
      setCamera("on");
    } catch (err) {
      trackerRef.current = null;
      tracker.stop();
      setCamera("error");
      setError(
        err instanceof DOMException && err.name === "NotAllowedError"
          ? "CAMERA ACCESS DENIED"
          : "TRACKING INIT FAILED",
      );
    }
  }, []);

  const toggleGestures = useCallback(() => {
    if (trackerRef.current) stopGestures();
    else void startGestures();
  }, [startGestures, stopGestures]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape" && voiceRef.current?.getState() === "speaking") {
        e.preventDefault();
        voiceRef.current.interrupt();
        return;
      }
      // Don't hijack shortcuts while typing in the chat box
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA")) return;

      switch (e.key) {
        case "+":
        case "=":
          sceneRef.current?.zoomIn();
          break;
        case "-":
        case "_":
          sceneRef.current?.zoomOut();
          break;
        case "r":
        case "R":
          sceneRef.current?.resetView();
          break;
        case "g":
        case "G":
          toggleGestures();
          break;
        case "v":
        case "V":
          if (!e.repeat) toggleVoice();
          break;
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [toggleGestures, toggleVoice]);

  const cameraOn = camera === "on";

  return (
    <>
      <div ref={containerRef} className="orb-root" />

      <div className="overlay-vignette" />
      <div className="overlay-grain" />
      <div className="overlay-scanlines" />

      <div className="hud hud-title">U.L.T.R.O.N.</div>

      <div className="hud hud-hint">
        <div>
          <span className="key">DRAG</span> spin&nbsp;&nbsp;
          <span className="key">SCROLL</span> zoom&nbsp;&nbsp;
          <span className="key">V</span> voice
        </div>
        {cameraOn ? (
          <div>
            <span className="key">PINCH + MOVE</span> spin&nbsp;&nbsp;
            <span className="key">PINCH BOTH HANDS ± SPREAD</span> zoom
          </div>
        ) : (
          <div>
            <span className="key">G</span> hand gestures&nbsp;&nbsp;
            <span className="key">R</span> reset&nbsp;&nbsp;
            <span className="key">+/−</span> zoom
          </div>
        )}
      </div>

      <div className="hud hud-voice">
        {voice !== "off" && <div className="voice-status">{VOICE_STATUS_LABEL[voice]}</div>}
        {userText && <div className="voice-line voice-user">&gt; {userText}</div>}
        {replyText && <div className="voice-line voice-reply">{replyText}</div>}
        {sources.length > 0 && (
          <ul className="voice-sources" aria-label="Research sources">
            {sources.map(({ title, url }) => (
              <li key={url}><a href={url} target="_blank" rel="noreferrer">{title}</a></li>
            ))}
          </ul>
        )}
        {voiceError && <div className="hud-error">{voiceError}</div>}
        <form className="voice-form" onSubmit={submitDraft}>
          <input
            type="text"
            className="voice-input"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="TYPE TO ULTRON…"
            aria-label="Message to ULTRON"
            autoComplete="off"
            spellCheck={false}
            maxLength={500}
          />
        </form>
      </div>

      <div className="hud hud-controls">
        <div className={`camera-panel${cameraOn ? " visible" : ""}`}>
          {/* Mirrored preview so it behaves like a mirror */}
          <video ref={videoRef} muted playsInline className="camera-video" />
          <canvas ref={overlayRef} width={208} height={156} className="camera-overlay" />
          <div className="camera-status">
            {status.hands > 0
              ? `${status.hands} HAND${status.hands > 1 ? "S" : ""} · ${MODE_LABEL[status.mode]}`
              : "SHOW HANDS"}
          </div>
        </div>

        {error && <div className="hud-error">{error}</div>}

        <div className="hud-row">
          <button
            type="button"
            className="hud-btn"
            aria-pressed={voice !== "off"}
            onClick={toggleVoice}
          >
            {VOICE_BUTTON_LABEL[voice]}
          </button>
          <button
            type="button"
            className="hud-btn"
            aria-pressed={cameraOn}
            onClick={toggleGestures}
            disabled={camera === "starting"}
          >
            {camera === "starting" ? "INITIALIZING…" : cameraOn ? "GESTURES ON" : "GESTURES OFF"}
          </button>
        </div>
        <div className="hud-row">
          <button type="button" className="hud-btn" onClick={() => sceneRef.current?.zoomIn()} aria-label="Zoom in">
            +
          </button>
          <button type="button" className="hud-btn" onClick={() => sceneRef.current?.zoomOut()} aria-label="Zoom out">
            −
          </button>
          <button type="button" className="hud-btn" onClick={() => sceneRef.current?.resetView()}>
            RESET
          </button>
        </div>
        <CredentialSettings onOpen={pauseForSettings} />
      </div>
    </>
  );
}
