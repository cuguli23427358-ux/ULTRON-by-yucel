const { isIP } = require("node:net");
const { Readable } = require("node:stream");
const { pipeline } = require("node:stream/promises");

const CLOUD_ROUTES = new Map([
  ["/api/chat", { bytes: 64_000, timeout: 32_000, daily: 200 }],
  ["/api/document", { bytes: 65_000, timeout: 55_000, daily: 25 }],
  ["/api/research", { bytes: 8_000, timeout: 30_000, daily: 30 }],
  ["/api/transcribe", { bytes: 800_000, timeout: 20_000, daily: 250 }],
  ["/api/tts", { bytes: 12_000, timeout: 16_000, daily: 200 }],
]);

function backendUrl(input, { allowLocal = false } = {}) {
  if (typeof input !== "string" || !input.trim()) throw new Error("Supply the hosted ULTRON HTTPS URL.");
  const url = new URL(input.trim());
  const hostname = url.hostname.replace(/^\[|\]$/g, "");
  const loopback = hostname === "localhost" || hostname === "::1" || hostname.startsWith("127.");
  if (url.username || url.password || url.search || url.hash || url.pathname !== "/" ||
      (url.protocol !== "https:" && !(allowLocal && loopback && url.protocol === "http:")) ||
      (!allowLocal && (loopback || isIP(hostname)))) {
    throw new Error("Use a public HTTPS origin without a path, query, or credentials.");
  }
  return url.origin;
}

function json(res, status, error, headers = {}) {
  res.writeHead(status, { "Content-Type": "application/json", "Cache-Control": "no-store", ...headers });
  res.end(JSON.stringify({ error }));
}

function validateRequest(req, pathname, limit, res) {
  const expected = pathname === "/api/transcribe" ? "multipart/form-data" : "application/json";
  const mediaType = req.headers["content-type"]?.split(";")[0]?.trim().toLowerCase();
  if (mediaType !== expected || req.headers["content-encoding"]) {
    json(res, 415, "unsupported_body");
    return false;
  }
  const length = req.headers["content-length"];
  if (!length || !/^\d+$/.test(length)) {
    json(res, 411, "length_required");
    return false;
  }
  if (Number(length) < 1 || Number(length) > limit.bytes) {
    json(res, 413, "request_too_large");
    return false;
  }
  return true;
}

async function forwardCloud(req, res, origin, pathname, limit) {
  if (!validateRequest(req, pathname, limit, res)) return;
  const connection = new AbortController();
  const disconnect = () => { if (!res.writableFinished) connection.abort(); };
  res.once("close", disconnect);
  try {
    const upstream = await fetch(origin + pathname, {
      method: "POST",
      headers: {
        "Content-Type": req.headers["content-type"],
        "Content-Length": req.headers["content-length"],
      },
      body: req,
      duplex: "half",
      redirect: "error",
      signal: AbortSignal.any([connection.signal, AbortSignal.timeout(limit.timeout)]),
    });
    res.writeHead(upstream.status, {
      "Content-Type": upstream.headers.get("content-type") || "application/json",
      "Cache-Control": "no-store",
      ...(upstream.headers.has("retry-after") ? { "Retry-After": upstream.headers.get("retry-after") } : {}),
    });
    if (upstream.body) await pipeline(Readable.fromWeb(upstream.body), res);
    else res.end();
  } catch (error) {
    if (!connection.signal.aborted && !res.headersSent) {
      json(res, 502, error.name === "TimeoutError" ? "timeout" : "shared_service_unavailable");
    } else if (!res.writableFinished) {
      res.destroy();
    }
  } finally {
    res.off("close", disconnect);
  }
}

module.exports = { CLOUD_ROUTES, backendUrl, forwardCloud, json, validateRequest };
