const { spawnSync } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");
const { parseEnv } = require("node:util");

const modelUrl = "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task";

async function download(url) {
  const response = await fetch(url, { signal: AbortSignal.timeout(60_000) });
  if (!response.ok) throw new Error("Could not download a required MediaPipe asset (HTTP " + response.status + ").");
  return Buffer.from(await response.arrayBuffer());
}

async function main() {
  const settings = parseEnv(fs.readFileSync(process.argv[2] || ".env.local", "utf8"));
  const names = ["OPENROUTER_API_KEY", "GROQ_API_KEY", "OPENROUTER_MODEL"];
  if (!settings.OPENROUTER_API_KEY?.trim() || !settings.GROQ_API_KEY?.trim()) {
    throw new Error("Set the OpenRouter and Groq keys before building the bundled installer.");
  }
  const content = names.filter((name) => settings[name]?.trim()).map((name) =>
    name + "=" + JSON.stringify(settings[name].trim())).join("\n") + "\n";

  const dist = path.resolve("dist");
  fs.mkdirSync(dist, { recursive: true });
  const staging = fs.mkdtempSync(path.join(dist, ".ultron-bundled-"));
  const files = {
    env: path.join(staging, ".env"),
    model: path.join(staging, "hand_landmarker.task"),
    license: path.join(staging, "APACHE-2.0.txt"),
    notice: path.join(staging, "NOTICE.txt"),
  };
  try {
    const [model, license] = await Promise.all([
      download(modelUrl),
      download("https://www.apache.org/licenses/LICENSE-2.0.txt"),
    ]);
    fs.writeFileSync(files.env, content, { mode: 0o600 });
    fs.writeFileSync(files.model, model);
    fs.writeFileSync(files.license, license);
    fs.writeFileSync(files.notice, "MediaPipe Hand Landmarker by Google\n" + modelUrl + "\nApache License 2.0\n");

    const next = spawnSync(process.execPath, [require.resolve("next/dist/bin/next"), "build"], {
      stdio: "inherit",
      env: { ...process.env, NEXT_PUBLIC_ULTRON_BUNDLED_VISION: "1" },
    });
    if (next.status !== 0) throw next.error || new Error("Next.js build failed.");
    const { build, Platform } = require("electron-builder");
    await build({
      targets: Platform.WINDOWS.createTarget(["nsis"]),
      config: {
        directories: { output: "dist/tek-setup" },
        extraMetadata: { ultronBundledCredentials: true },
        extraResources: [
          { from: files.env, to: ".env" },
          { from: files.model, to: "app/public/ultron-vision/hand_landmarker.task" },
          { from: files.license, to: "app/public/ultron-vision/APACHE-2.0.txt" },
          { from: files.notice, to: "app/public/ultron-vision/NOTICE.txt" },
          { from: "node_modules/@mediapipe/tasks-vision/wasm", to: "app/public/ultron-vision/wasm" },
        ],
        fileAssociations: [],
      },
    });
  } finally {
    for (const file of Object.values(files)) {
      if (fs.existsSync(file)) fs.unlinkSync(file);
    }
    fs.rmdirSync(staging);
  }
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
