import { apiSetting } from "@/lib/apiSettings";

export const runtime = "nodejs";

const MODEL = "mistralai/voxtral-mini-tts-2603";
const VOICE = "en_paul_confident";

export async function POST(req: Request) {
  const key = apiSetting("OPENROUTER_API_KEY");
  if (!key) return Response.json({ error: "missing_key" }, { status: 503 });

  const data = await req.json().catch(() => null);
  const text = typeof data?.text === "string" ? data.text.trim() : "";
  if (!text || text.length > 2000) {
    return Response.json({ error: "bad_request" }, { status: 400 });
  }

  try {
    const upstream = await fetch("https://openrouter.ai/api/v1/audio/speech", {
      method: "POST",
      headers: { Authorization: "Bearer " + key, "Content-Type": "application/json" },
      body: JSON.stringify({ model: MODEL, voice: VOICE, input: text, response_format: "mp3" }),
      signal: AbortSignal.any([req.signal, AbortSignal.timeout(12_000)]),
    });
    if (!upstream.ok || !upstream.body || !upstream.headers.get("content-type")?.startsWith("audio/")) {
      void upstream.body?.cancel().catch(() => {});
      return Response.json({ error: "upstream", status: upstream.status }, { status: 502 });
    }
    return new Response(upstream.body, {
      headers: { "Content-Type": "audio/mpeg", "Cache-Control": "no-store" },
    });
  } catch {
    return Response.json({ error: "speech_unavailable" }, { status: 502 });
  }
}
