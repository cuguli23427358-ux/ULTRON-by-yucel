const { createHash } = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { backendUrl } = require("./cloud.cjs");

const PROFILE_NAME = "ULTRON-Connection.ultron";
const PROFILE_FORMAT = "ultron.connection";

function profileHash(profile) {
  return createHash("sha256").update(profile).digest("hex");
}

function createConnectionProfile(origin) {
  return Buffer.from(JSON.stringify({
    format: PROFILE_FORMAT,
    version: 1,
    gateway: backendUrl(origin),
  }, null, 2) + "\n", "utf8");
}

function installedBackend(metadata, resourcesPath) {
  if (!Object.hasOwn(metadata, "ultronConnectionSha256")) {
    return metadata.ultronBackendUrl ? backendUrl(metadata.ultronBackendUrl) : null;
  }

  const expected = metadata.ultronConnectionSha256;
  const file = path.join(resourcesPath, PROFILE_NAME);
  let profile;
  try {
    const info = fs.lstatSync(file);
    if (!info.isFile() || info.size < 1 || info.size > 4_096) throw new Error("Invalid profile file");
    profile = fs.readFileSync(file);
  } catch {
    throw new Error("The ULTRON connection profile is missing or unreadable. Reinstall ULTRON.");
  }

  if (profileHash(profile) !== expected) {
    throw new Error("The ULTRON connection profile has changed. Reinstall ULTRON.");
  }

  try {
    const data = JSON.parse(profile.toString("utf8"));
    if (data.format !== PROFILE_FORMAT || data.version !== 1) throw new Error("Unsupported profile");
    return backendUrl(data.gateway);
  } catch {
    throw new Error("The ULTRON connection profile is invalid. Reinstall ULTRON.");
  }
}

module.exports = { PROFILE_NAME, createConnectionProfile, installedBackend, profileHash };
