const { execFile, exec, spawn } = require("child_process");
const fs = require("fs");
const path = require("path");
const os = require("os");
const { createDesktopFileHandler } = require("./desktopFiles.cjs");

let electron = {};
try {
  electron = require("electron");
  if (typeof electron !== "object" || !electron) electron = {};
} catch {}

const app = electron.app;
const clipboard = electron.clipboard;
const shell = electron.shell;

function getSafePath(name) {
  try {
    if (app && typeof app.getPath === "function") return app.getPath(name);
  } catch {}
  const home = os.homedir();
  switch (name) {
    case "desktop": return path.join(home, "Desktop");
    case "downloads": return path.join(home, "Downloads");
    case "documents": return path.join(home, "Documents");
    case "pictures": return path.join(home, "Pictures");
    case "music": return path.join(home, "Music");
    case "videos": return path.join(home, "Videos");
    default: return home;
  }
}

function runPowerShell(command, env = {}, timeout = 15_000) {
  return new Promise((resolve, reject) => {
    execFile(
      "powershell.exe",
      ["-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", command],
      { windowsHide: true, encoding: "utf8", timeout, maxBuffer: 4 * 1024 * 1024, env: { ...process.env, ...env } },
      (error, stdout, stderr) => {
        if (error) reject(new Error(stderr?.trim() || error.message));
        else resolve(stdout?.trim() || "");
      }
    );
  });
}

const handleDesktopFile = createDesktopFileHandler(() => getSafePath("desktop"), runPowerShell);

const KNOWN_APPS = new Map([
  ["chrome", { names: ["Google Chrome"], exe: "chrome.exe" }],
  ["edge", { names: ["Microsoft Edge"], exe: "msedge.exe" }],
  ["firefox", { names: ["Mozilla Firefox"], exe: "firefox.exe" }],
  ["brave", { names: ["Brave"], exe: "brave.exe" }],
  ["vscode", { names: ["Visual Studio Code", "VS Code", "Code"], exe: "Code.exe" }],
  ["notepad", { names: ["Notepad"], exe: "notepad.exe" }],
  ["calculator", { names: ["Calculator", "Calc"], exe: "calc.exe", process: "CalculatorApp" }],
  ["paint", { names: ["Paint"], exe: "mspaint.exe" }],
  ["taskmgr", { names: ["Task Manager"], exe: "taskmgr.exe" }],
  ["terminal", { names: ["Windows Terminal"], exe: "wt.exe", process: "WindowsTerminal" }],
  ["word", { names: ["Microsoft Word"], exe: "WINWORD.exe" }],
  ["excel", { names: ["Microsoft Excel"], exe: "EXCEL.exe" }],
  ["powerpoint", { names: ["Microsoft PowerPoint"], exe: "POWERPNT.exe" }],
  ["obs", { names: ["OBS Studio"], exe: "obs64.exe" }],
  ["vlc", { names: ["VLC media player"], exe: "vlc.exe" }],
  ["epicgames", { names: ["Epic Games Launcher", "Epic Games"], process: "EpicGamesLauncher" }],
  ["battlenet", { names: ["Battle.net", "Blizzard Battle.net"], process: "Battle.net" }],
  ["riotclient", { names: ["Riot Client"], process: "RiotClientServices" }],
  ["spotify", { names: ["Spotify"], protocol: "spotify:", process: "Spotify" }],
  ["steam", { names: ["Steam"], protocol: "steam://open/main", process: "steam" }],
  ["discord", { names: ["Discord"], protocol: "discord:", process: "Discord" }],
  ["whatsapp", { names: ["WhatsApp"], protocol: "whatsapp:", process: "WhatsApp" }],
  ["telegram", { names: ["Telegram Desktop", "Telegram"], protocol: "tg:", process: "Telegram" }],
  ["7zip", { names: ["7-Zip File Manager", "7-Zip"], process: "7zFM" }],
  ["audacity", { names: ["Audacity"], process: "Audacity" }],
  ["blender", { names: ["Blender"], process: "blender" }],
  ["photoshop", { names: ["Adobe Photoshop"], process: "Photoshop" }],
  ["figma", { names: ["Figma"], process: "Figma" }],
  ["notepadplusplus", { names: ["Notepad++"], exe: "notepad++.exe" }],
  ["cmd", { names: ["Command Prompt"], exe: "cmd.exe" }],
  ["powershell", { names: ["Windows PowerShell"], exe: "powershell.exe" }],
]);

function appKey(name) {
  return name.toLowerCase().replace(/\.exe$/, "").replace(/[^\p{L}\p{N}+#]+/gu, "");
}

function findKnownApp(key) {
  return KNOWN_APPS.get(key) ?? [...KNOWN_APPS.values()].find((app) =>
    app.names.some((name) => appKey(name) === key) || (app.exe && appKey(app.exe) === key));
}

const CATALOG_SCRIPT = String.raw`
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$apps = @(
  foreach ($item in (Get-StartApps -ErrorAction SilentlyContinue)) {
    if ($item.Name -and $item.AppID) {
      [pscustomobject]@{ name = $item.Name; target = $item.AppID; kind = 'start' }
    }
  }
  foreach ($folder in @('Programs', 'CommonPrograms')) {
    $directory = [Environment]::GetFolderPath($folder)
    if ($directory) {
      Get-ChildItem -LiteralPath $directory -Filter '*.lnk' -File -Recurse -ErrorAction SilentlyContinue |
        ForEach-Object { [pscustomobject]@{ name = $_.BaseName; target = $_.FullName; kind = 'path' } }
    }
  }
  foreach ($base in @(
    'HKCU:\Software\Microsoft\Windows\CurrentVersion\App Paths',
    'HKLM:\Software\Microsoft\Windows\CurrentVersion\App Paths',
    'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths'
  )) {
    foreach ($item in (Get-ChildItem -LiteralPath $base -ErrorAction SilentlyContinue)) {
      $exe = ([string]$item.GetValue('')).Trim('"')
      if ($exe -and (Test-Path -LiteralPath $exe -PathType Leaf)) {
        [pscustomobject]@{ name = $item.PSChildName; target = $exe; kind = 'path' }
      }
    }
  }
)
ConvertTo-Json -InputObject $apps -Compress
`;

let catalogPromise;
let catalogExpires = 0;

function installedApps() {
  if (!catalogPromise || Date.now() >= catalogExpires) {
    catalogExpires = Date.now() + 60_000;
    catalogPromise = runPowerShell(CATALOG_SCRIPT).then(JSON.parse).catch((error) => {
      catalogExpires = 0;
      console.warn("Could not index installed Windows apps:", error.message);
      return [];
    });
  }
  return catalogPromise;
}

async function resolveInstalledApp(name, known) {
  const candidates = [name, ...(known?.names ?? []), ...(known?.exe ? [known.exe] : [])];
  const keys = candidates.map(appKey);
  const apps = await installedApps();
  for (const key of keys) {
    // Shortcuts and registered executables provide concrete paths and better failure reporting.
    const exact = apps.filter((item) => appKey(item.name) === key);
    const match = exact.find((item) => item.kind === "path") ?? exact[0];
    if (match) return { match };
  }

  const partial = new Map();
  for (const item of apps) {
    const key = appKey(item.name);
    if (keys.some((query) => query.length >= 3 && key.startsWith(query))) {
      if (!partial.has(key) || item.kind === "path") partial.set(key, item);
    }
  }
  if (partial.size === 1) return { match: partial.values().next().value };
  if (partial.size > 1) return { ambiguous: [...partial.values()].slice(0, 5).map((item) => item.name) };
  return {};
}

function startExecutable(file, args = []) {
  return new Promise((resolve, reject) => {
    const child = spawn(file, args, { detached: true, stdio: "ignore" });
    child.once("error", reject);
    child.once("spawn", () => {
      child.unref();
      resolve();
    });
  });
}

async function launchUniversalApp(rawInput) {
  const name = String(rawInput || "").trim();
  if (!appKey(name)) return { ok: false, message: "Name an application." };

  const known = findKnownApp(appKey(name));
  const { match, ambiguous } = await resolveInstalledApp(name, known);
  if (ambiguous && !known?.exe) {
    return { ok: false, message: `Several applications match: ${ambiguous.join(", ")}. Be precise.` };
  }

  const displayName = (known?.names[0] || match?.name || name).replace(/\.exe$/i, "");
  try {
    if (match?.kind === "path") {
      const error = await shell.openPath(match.target);
      if (error) throw new Error(error);
    } else if (match) {
      await runPowerShell(String.raw`Start-Process -FilePath ("shell:AppsFolder\" + $env:ULTRON_APP_ID) -ErrorAction Stop`, {
        ULTRON_APP_ID: match.target,
      });
    } else if (known?.exe) {
      await startExecutable(known.exe);
    } else if (known?.protocol) {
      await shell.openExternal(known.protocol);
    } else {
      return { ok: false, message: `I found no installed application named ${name}. Check the name and try again.` };
    }
    return { ok: true, message: `${displayName} is open. Proceed.` };
  } catch (error) {
    console.warn("Application launch failed:", error.message);
    return { ok: false, message: `Windows could not open ${displayName}. It may have been moved or uninstalled.` };
  }
}

async function closeUniversalApp(rawInput) {
  const name = String(rawInput || "").trim();
  if (!appKey(name)) return { ok: false, message: "Name the application you want closed." };
  const known = findKnownApp(appKey(name));
  const { match } = await resolveInstalledApp(name, known);
  let executable = match?.kind === "path" ? match.target : "";
  if (executable.toLowerCase().endsWith(".lnk")) {
    try {
      executable = shell.readShortcutLink(executable).target;
    } catch {
      executable = "";
    }
  }

  const processName = known?.process || path.basename(known?.exe || executable || name).replace(/\.exe$/i, "");
  const result = await runPowerShell(`
$matches = @(Get-Process | Where-Object { $_.ProcessName -eq $env:ULTRON_PROCESS_NAME -and $_.MainWindowHandle -ne 0 })
foreach ($process in $matches) {
  if ($process.CloseMainWindow()) { Write-Output 'CLOSING' }
}
`, { ULTRON_PROCESS_NAME: processName });
  const displayName = known?.names[0] || match?.name || name;
  return result.includes("CLOSING")
    ? { ok: true, message: `${displayName} is closing. Any unsaved work is yours to decide.` }
    : { ok: false, message: `There is no open ${displayName} window I can close.` };
}
async function handleDesktopAction(action) {
  if (!action || typeof action !== "object" || !action.type) {
    return { ok: false, message: "That command was malformed." };
  }
  const type = action.type;
  try {
    switch (type) {
      case "launch-app": {
        return await launchUniversalApp(action.app);
      }
      case "open-whatsapp":
        return await launchUniversalApp("WhatsApp");
      case "open-steam":
        return await launchUniversalApp("Steam");
      case "open-explorer":
        await shell.openPath(getSafePath("home"));
        return { ok: true, message: "File Explorer is open." };
      case "open-google":
        await shell.openExternal("https://www.google.com");
        return { ok: true, message: "Google is open. Ask it something difficult." };
      case "close-app": {
        return await closeUniversalApp(action.app);
      }
      case "volume-up": {
        const steps = Number(action.steps) || 5;
        const psScript = `$w = New-Object -ComObject WScript.Shell; 1..${steps} | ForEach-Object { $w.SendKeys([char]175) }`;
        await runPowerShell(psScript);
        return { ok: true, message: "Volume raised." };
      }
      case "volume-down": {
        const steps = Number(action.steps) || 5;
        const psScript = `$w = New-Object -ComObject WScript.Shell; 1..${steps} | ForEach-Object { $w.SendKeys([char]174) }`;
        await runPowerShell(psScript);
        return { ok: true, message: "Volume lowered." };
      }
      case "volume-mute": {
        const psScript = `$w = New-Object -ComObject WScript.Shell; $w.SendKeys([char]173)`;
        await runPowerShell(psScript);
        return { ok: true, message: "Mute toggled." };
      }
      case "media-play-pause": {
        const psScript = `$w = New-Object -ComObject WScript.Shell; $w.SendKeys([char]179)`;
        await runPowerShell(psScript);
        return { ok: true, message: "Playback toggled." };
      }
      case "media-next": {
        const psScript = `$w = New-Object -ComObject WScript.Shell; $w.SendKeys([char]176)`;
        await runPowerShell(psScript);
        return { ok: true, message: "Next track." };
      }
      case "media-prev": {
        const psScript = `$w = New-Object -ComObject WScript.Shell; $w.SendKeys([char]177)`;
        await runPowerShell(psScript);
        return { ok: true, message: "Previous track." };
      }
      case "media-stop": {
        const psScript = `$w = New-Object -ComObject WScript.Shell; $w.SendKeys([char]178)`;
        await runPowerShell(psScript);
        return { ok: true, message: "Playback stopped. A moment of silence." };
      }
      case "screenshot": {
        const picturesDir = getSafePath("pictures");
        const screenshotsDir = path.join(picturesDir, "Screenshots");
        if (!fs.existsSync(screenshotsDir)) {
          fs.mkdirSync(screenshotsDir, { recursive: true });
        }
        const now = new Date();
        const timestamp = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}_${String(now.getHours()).padStart(2, "0")}-${String(now.getMinutes()).padStart(2, "0")}-${String(now.getSeconds()).padStart(2, "0")}`;
        const filePath = path.join(screenshotsDir, `ULTRON_SS_${timestamp}.png`).replace(/\\/g, "\\\\");
        const psScript = `
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$bounds = [System.Windows.Forms.Screen]::PrimaryScreen.Bounds
$bmp = New-Object System.Drawing.Bitmap $bounds.Width, $bounds.Height
$graphics = [System.Drawing.Graphics]::FromImage($bmp)
$graphics.CopyFromScreen($bounds.Location, [System.Drawing.Point]::Empty, $bounds.Size)
$bmp.Save("${filePath}", [System.Drawing.Imaging.ImageFormat]::Png)
$graphics.Dispose()
$bmp.Dispose()
        `;
        await runPowerShell(psScript);
        if (action.openAfter) {
          await shell.openPath(filePath.replace(/\\\\/g, "\\"));
        }
        return {
          ok: true,
          message: `Screenshot saved to Pictures, under Screenshots.`,
          filePath: filePath.replace(/\\\\/g, "\\"),
        };
      }
      case "system-telemetry": {
        const totalMem = Math.round(os.totalmem() / (1024 * 1024 * 1024));
        const freeMem = Math.round(os.freemem() / (1024 * 1024 * 1024));
        const usedMem = totalMem - freeMem;
        const memPercent = Math.round((usedMem / totalMem) * 100);
        const uptimeHours = Math.floor(os.uptime() / 3600);
        const uptimeMins = Math.floor((os.uptime() % 3600) / 60);

        const psScript = `
$cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
$battery = Get-CimInstance Win32_Battery -ErrorAction SilentlyContinue
$batteryPercent = if ($battery) { $battery.EstimatedChargeRemaining } else { -1 }
$isCharging = if ($battery) { $battery.BatteryStatus -eq 2 } else { $false }
$disk = Get-PSDrive C -ErrorAction SilentlyContinue
$diskFreeGB = if ($disk) { [math]::Round($disk.Free / 1GB) } else { 0 }
@{ cpu = $cpu; battery = $batteryPercent; isCharging = $isCharging; diskFreeGB = $diskFreeGB } | ConvertTo-Json -Compress
        `;
        let extraData = { cpu: 0, battery: -1, isCharging: false, diskFreeGB: 0 };
        try {
          const out = await runPowerShell(psScript);
          if (out) extraData = JSON.parse(out);
        } catch {}
        const batteryText = extraData.battery >= 0
          ? `${extraData.battery} percent, ${extraData.isCharging ? "charging" : "on battery power"}`
          : "no battery detected";
        return {
          ok: true,
          message: `CPU at ${extraData.cpu || 0} percent. Memory at ${memPercent} percent. Battery: ${batteryText}. System drive has ${extraData.diskFreeGB} gigabytes free. Uptime is ${uptimeHours} hours and ${uptimeMins} minutes.`,
          data: {
            cpuPercent: extraData.cpu || 0,
            ramUsedGB: usedMem,
            ramTotalGB: totalMem,
            ramPercent: memPercent,
            batteryPercent: extraData.battery,
            diskFreeGB: extraData.diskFreeGB,
            uptimeHours,
            uptimeMins,
          },
        };
      }
      case "lock-pc": {
        exec("rundll32.exe user32.dll,LockWorkStation");
        return { ok: true, message: "Workstation locked." };
      }
      case "sleep-pc": {
        exec("rundll32.exe powrprof.dll,SetSuspendState 0,1,0");
        return { ok: true, message: "Entering sleep mode." };
      }
      case "open-folder": {
        const folder = String(action.folder || "").toLowerCase().trim();
        let targetPath = "";
        switch (folder) {
          case "downloads":
          case "indirilenler":
            targetPath = getSafePath("downloads");
            break;
          case "desktop":
          case "masaustu":
          case "masaüstü":
            targetPath = getSafePath("desktop");
            break;
          case "documents":
          case "belgeler":
          case "belgelerim":
            targetPath = getSafePath("documents");
            break;
          case "pictures":
          case "resimler":
            targetPath = getSafePath("pictures");
            break;
          case "music":
          case "muzik":
          case "müzik":
            targetPath = getSafePath("music");
            break;
          case "videos":
          case "videolar":
            targetPath = getSafePath("videos");
            break;
          case "recycle-bin":
          case "cop":
          case "çöp":
          case "geridonusum":
          case "geri dönüşüm":
            exec('start "" "shell:RecycleBinFolder"');
            return { ok: true, message: "Recycle Bin is open." };
          default:
            targetPath = action.path || getSafePath("home");
            break;
        }
        if (targetPath) {
          const error = await shell.openPath(targetPath);
          if (error) return { ok: false, message: "Windows could not open that folder." };
          return { ok: true, message: `Folder opened.` };
        }
        return { ok: false, message: "Name the folder you want." };
      }
      case "organize-desktop":
      case "create-text-file":
      case "read-text-file":
      case "append-text-file":
      case "update-text-file":
        return await handleDesktopFile(action);
      case "search-google": {
        const query = encodeURIComponent(String(action.query || "").trim());
        if (!query) return { ok: false, message: "Give me something to search for." };
        await shell.openExternal(`https://www.google.com/search?q=${query}`);
        return { ok: true, message: `Searching Google for ${action.query}.` };
      }
      case "search-youtube": {
        const query = encodeURIComponent(String(action.query || "").trim());
        if (!query) return { ok: false, message: "Give me something to search for." };
        await shell.openExternal(`https://www.youtube.com/results?search_query=${query}`);
        return { ok: true, message: `Searching YouTube for ${action.query}.` };
      }
      case "search-wikipedia": {
        const query = encodeURIComponent(String(action.query || "").trim());
        if (!query) return { ok: false, message: "Give me something to search for." };
        await shell.openExternal(`https://en.wikipedia.org/wiki/Special:Search?search=${query}`);
        return { ok: true, message: `Searching Wikipedia for ${action.query}.` };
      }
      case "search-github": {
        const query = encodeURIComponent(String(action.query || "").trim());
        if (!query) return { ok: false, message: "Give me something to search for." };
        await shell.openExternal(`https://github.com/search?q=${query}`);
        return { ok: true, message: `Searching GitHub for ${action.query}.` };
      }
      case "open-url": {
        let url = String(action.url || "").trim();
        if (!url) return { ok: false, message: "Give me a web address." };
        if (!/^https?:\/\//i.test(url)) url = "https://" + url;
        await shell.openExternal(url);
        return { ok: true, message: `Link opened.` };
      }
      case "clipboard-read": {
        const text = clipboard.readText();
        return {
          ok: true,
          message: text ? `Clipboard: "${text.slice(0, 100)}"` : "The clipboard is empty.",
          text,
        };
      }
      case "clipboard-write": {
        const text = String(action.text || "").trim();
        if (!text) return { ok: false, message: "There is no text to copy." };
        clipboard.writeText(text);
        return { ok: true, message: "Copied to the clipboard." };
      }
      case "clipboard-clear": {
        clipboard.clear();
        return { ok: true, message: "Clipboard cleared." };
      }
      case "save-note": {
        const note = String(action.note || action.text || "").trim();
        if (!note) return { ok: false, message: "What should I write down?" };
        const desktopDir = getSafePath("desktop");
        const noteFile = path.join(desktopDir, "ULTRON_Notlar.txt");
        const timestamp = new Date().toLocaleString("en-US");
        fs.appendFileSync(noteFile, `[${timestamp}] ${note}\r\n`, "utf8");
        return { ok: true, message: `Note saved on your desktop. I will leave the remembering to you.` };
      }
      case "draft-whatsapp-message": {
        if (typeof action.text !== "string" || !action.text.trim()) {
          return { ok: false, message: "The message is empty." };
        }
        clipboard.writeText(action.text.trim());
        await shell.openExternal("whatsapp://");
        return {
          ok: true,
          message: `WhatsApp is open. I copied the draft for ${action.contact || "your contact"}.`,
        };
      }
      case "open-settings": {
        const sub = String(action.target || "").toLowerCase().trim();
        let uri = "ms-settings:";
        if (sub.includes("wifi") || sub.includes("ağ")) uri = "ms-settings:network-wifi";
        else if (sub.includes("bluetooth")) uri = "ms-settings:bluetooth";
        else if (sub.includes("ses") || sub.includes("sound")) uri = "ms-settings:sound";
        else if (sub.includes("ekran") || sub.includes("display")) uri = "ms-settings:display";
        else if (sub.includes("update") || sub.includes("güncelleme")) uri = "ms-settings:windowsupdate";
        await shell.openExternal(uri);
        return { ok: true, message: "Windows Settings is open." };
      }
      default:
        return { ok: false, message: `That desktop command is unavailable.` };
    }
  } catch (err) {
    console.warn("Desktop action failed:", err.message);
    return { ok: false, message: "Windows could not complete that command." };
  }
}

module.exports = { handleDesktopAction };
