import { apiSetting } from "@/lib/apiSettings";

export interface CompletionMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

interface CompletionOptions {
  maxTokens: number;
  temperature: number;
  timeoutPerProvider?: number;
  rejectTruncation?: boolean;
  validate?: (reply: string) => string | null;
}

export async function completeText(
  signal: AbortSignal,
  messages: CompletionMessage[],
  options: CompletionOptions,
): Promise<Response> {
  const openRouterKey = apiSetting("OPENROUTER_API_KEY");
  const groqKey = apiSetting("GROQ_API_KEY");
  if (!openRouterKey && !groqKey) {
    return Response.json({ error: "missing_key" }, { status: 503 });
  }

  const providers = [
    {
      url: "https://openrouter.ai/api/v1/chat/completions",
      key: openRouterKey,
      model: apiSetting("OPENROUTER_MODEL") || "openai/gpt-4o-mini",
      timeout: 15_000,
      options: {},
    },
    {
      url: "https://api.groq.com/openai/v1/chat/completions",
      key: groqKey,
      model: "qwen/qwen3.8-27b",
      timeout: 12_000,
      options: { reasoning_effort: "none" },
    },
  ];

  let failure: { error: string; status?: number } | undefined;
  for (const provider of providers) {
    if (!provider.key || signal.aborted) continue;
    try {
      const upstream = await fetch(provider.url, {
        method: "POST",
        headers: {
          Authorization: "Bearer " + provider.key,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...provider.options,
          model: provider.model,
          messages,
          max_tokens: options.maxTokens,
          temperature: options.temperature,
        }),
        signal: AbortSignal.any([signal, AbortSignal.timeout(options.timeoutPerProvider ?? provider.timeout)]),
      });
      if (!upstream.ok) {
        void upstream.body?.cancel().catch(() => {});
        failure ??= { error: "upstream", status: upstream.status };
        continue;
      }

      const choice = (await upstream.json())?.choices?.[0];
      if (options.rejectTruncation && (choice?.finish_reason === "length" || choice?.finish_reason === "content_filter")) {
        failure = { error: "incomplete_document" };
        continue;
      }
      const reply = choice?.message?.content;
      if (typeof reply === "string" && reply.trim()) {
        const reason = options.validate?.(reply.trim());
        if (!reason) return Response.json({ reply: reply.trim() });
        failure = { error: reason };
        continue;
      }
      failure ??= { error: "empty" };
    } catch (error) {
      failure ??= { error: error instanceof Error && error.name === "TimeoutError" ? "timeout" : "network" };
    }
  }

  return Response.json(failure ?? { error: "network" }, { status: 502 });
}
