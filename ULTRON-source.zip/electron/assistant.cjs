const fs = require("node:fs");
const path = require("node:path");
const { randomUUID } = require("node:crypto");
const chrono = require("chrono-node/en");

const TIME = new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" });
const DATE_TIME = new Intl.DateTimeFormat("en-US", {
  weekday: "long", month: "short", day: "numeric", hour: "numeric", minute: "2-digit",
});
const KINDS = new Set(["event", "reminder", "timer"]);
const MAX_ENTRIES = 1_000;

class AssistantError extends Error {}

function clean(value) {
  return typeof value === "string" ? value.trim().replace(/^["“](.+)["”]$/s, "$1").slice(0, 500) : "";
}

function normalized(text) {
  return clean(text).toLowerCase().replace(/[\p{P}\p{S}\s]+/gu, " ").trim();
}

function findOne(items, name, noun) {
  const query = normalized(name).replace(/^(?:the |my )/, "");
  const exact = items.filter((item) => normalized(item.text) === query);
  const results = exact.length ? exact : items.filter((item) => !query || normalized(item.text).includes(query));
  if (!results.length) throw new AssistantError(`I found no matching ${noun}.`);
  if (results.length > 1) {
    throw new AssistantError(`Several items match: ${results.slice(0, 4).map((item) => item.text).join(", ")}. Be more specific.`);
  }
  return results[0];
}

function whenFor(text, now, kind) {
  const reference = new Date(now);
  const input = kind === "timer" ? "in " + text.replace(/^in\s+/i, "") : text;
  const matches = chrono.parse(input, reference, { forwardDate: true });
  if (matches.length !== 1 || !matches[0].start.isCertain("hour")) {
    throw new AssistantError(kind === "timer"
      ? "Give me a duration, like five minutes."
      : "Give me one clear date and time, like tomorrow at 10 AM.");
  }
  const match = matches[0];
  if (kind === "timer" && (!/^in\s+/i.test(match.text) || match.index !== 0)) {
    throw new AssistantError("Give me a duration, like five minutes.");
  }
  const at = match.start.date().getTime();
  if (!Number.isFinite(at) || at <= now) throw new AssistantError("Choose a time in the future.");
  const name = input.slice(0, match.index).trimEnd() + " " + input.slice(match.index + match.text.length).trimStart();
  const title = clean(name.replace(/^\s*(?:to |about |for |called |named )+/i, "").replace(/\s+(?:at|on|in|for)\s*$/i, ""));
  if (kind !== "timer" && !title) throw new AssistantError("Tell me what this is for.");
  const end = match.end?.date().getTime();
  return { at, text: title || "Timer", ...(kind === "event" && end > at ? { endsAt: end } : {}) };
}

function dateRange(range, now) {
  const reference = new Date(now);
  if (range === "upcoming") return { from: now, to: Infinity, label: "upcoming" };
  const date = chrono.parseDate(range || "today", reference, { forwardDate: true });
  if (!date) throw new AssistantError("Choose a date such as today or tomorrow.");
  date.setHours(0, 0, 0, 0);
  const week = /^(?:this|next) week$/.test(range);
  if (week) date.setDate(date.getDate() - (date.getDay() + 6) % 7);
  const end = new Date(date);
  end.setDate(end.getDate() + (week ? 7 : 1));
  return { from: +date, to: +end, label: range || "today" };
}

function durationText(milliseconds) {
  let remaining = Math.max(1, Math.ceil(milliseconds / 1000));
  const pieces = [];
  for (const [seconds, label] of [[86_400, "day"], [3_600, "hour"], [60, "minute"], [1, "second"]]) {
    const amount = Math.floor(remaining / seconds);
    if (amount) pieces.push(`${amount} ${label}${amount === 1 ? "" : "s"}`);
    remaining %= seconds;
  }
  return pieces.join(" and ");
}

function writeState(file, state) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tempfile = path.join(path.dirname(file), `assistant-${randomUUID()}.tmp`);
  fs.writeFileSync(tempfile, JSON.stringify(state), { encoding: "utf8", flag: "wx" });
  try {
    fs.renameSync(tempfile, file);
  } finally {
    if (fs.existsSync(tempfile)) fs.unlinkSync(tempfile);
  }
}

function readState(file) {
  try {
    const data = JSON.parse(fs.readFileSync(file, "utf8"));
    if (data.version !== 1 || !Array.isArray(data.items) || !Array.isArray(data.tasks) || !Array.isArray(data.notes)) {
      throw new Error("Unrecognized assistant data");
    }
    return data;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    return { version: 1, items: [], tasks: [], notes: [] };
  }
}

function createAssistant(file, { notify, clock = Date.now, legacyNotes = () => [] }) {
  let state;
  let alarm;
  let running = false;

  function getState() {
    state ??= readState(file);
    return state;
  }

  function save(next) {
    writeState(file, next);
    state = next;
    arm();
  }

  function activeAlerts() {
    return getState().items.filter((item) => item.kind !== "event" && !item.cancelledAt && !item.notifiedAt);
  }

  function arm() {
    clearTimeout(alarm);
    if (!running) return;
    const next = activeAlerts().reduce((soonest, item) => Math.min(soonest, item.at), Infinity);
    if (Number.isFinite(next)) alarm = setTimeout(tick, Math.max(0, Math.min(60_000, next - clock())));
  }

  function tick() {
    if (!running) return;
    const now = clock();
    try {
      const due = activeAlerts().filter((item) => item.at <= now).slice(0, 6);
      if (!due.length) { arm(); return; }
      const delivered = new Set();
      for (const item of due) {
        if (notify(item)) delivered.add(item.id);
      }
      if (delivered.size) {
        const current = getState();
        const items = current.items.map((item) => delivered.has(item.id) ? { ...item, notifiedAt: now } : item);
        writeState(file, { ...current, items });
        state = { ...current, items };
      }
      alarm = setTimeout(tick, delivered.size ? 250 : 30_000);
    } catch (error) {
      console.error("ULTRON reminder delivery failed:", error.code || error.message);
      alarm = setTimeout(tick, 30_000);
    }
  }

  function run(command) {
    if (!command || typeof command !== "object") throw new AssistantError("That assistant command was malformed.");
    const current = getState();
    const now = clock();
    const text = clean(command.text);
    const makeItem = (value) => ({ id: randomUUID(), createdAt: now, ...value });
    const insert = (key, value) => {
      if (current[key].length >= MAX_ENTRIES) {
        if (key !== "items") throw new AssistantError("Your local list has reached its storage limit.");
        const liveItems = current.items.filter((item) => !item.cancelledAt && !item.notifiedAt && item.at >= now);
        if (liveItems.length >= MAX_ENTRIES) throw new AssistantError("Your local calendar has reached its storage limit.");
        save({ ...current, items: [...liveItems, makeItem(value)] });
        return;
      }
      save({ ...current, [key]: [...current[key], makeItem(value)] });
    };

    switch (command.operation) {
      case "timer":
      case "remind":
      case "schedule": {
        const kind = { timer: "timer", remind: "reminder", schedule: "event" }[command.operation];
        const item = whenFor(text, now, kind);
        const date = DATE_TIME.format(item.at);
        insert("items", { kind, ...item });
        return kind === "event" ? `Scheduled ${item.text} for ${date}.`
          : kind === "timer" ? `Set ${item.text === "Timer" ? "a timer" : "the " + item.text + " timer"} for ${durationText(item.at - now)}.`
            : `I'll remind you to ${item.text} on ${date}.`;
      }
      case "cancel": {
        if (!KINDS.has(command.kind)) throw new AssistantError("Choose a timer, reminder, or calendar event.");
        const matching = current.items.filter((item) => item.kind === command.kind &&
          !item.notifiedAt && !item.cancelledAt && item.at > now);
        const selected = findOne(matching, text, command.kind);
        save({ ...current, items: current.items.map((item) => item.id === selected.id ? { ...item, cancelledAt: now } : item) });
        return `Cancelled ${selected.text}.`;
      }
      case "agenda":
      case "alerts":
      case "briefing": {
        const { from, to, label } = dateRange(clean(command.range), now);
        const scheduled = current.items.filter((item) => !item.cancelledAt && item.at >= from && item.at < to)
          .sort((a, b) => a.at - b.at);
        const events = scheduled.filter((item) => item.kind === "event");
        const alerts = scheduled.filter((item) => item.kind !== "event" && !item.notifiedAt);
        const day = to - from <= 25 * 60 * 60 * 1000;
        const summary = (items, noun) => {
          if (!items.length) return `No ${noun} ${label === "upcoming" ? "coming up" : "for " + label}.`;
          const shown = items.slice(0, 4).map((item) => {
            const format = day ? TIME : DATE_TIME;
            return `${item.text} at ${format.format(item.at)}${item.endsAt ? " until " + format.format(item.endsAt) : ""}`;
          });
          return `${noun}: ${shown.join("; ")}.${items.length > shown.length ? ` Plus ${items.length - shown.length} more.` : ""}`;
        };
        if (command.operation === "agenda") return summary(events, "calendar events");
        if (command.operation === "alerts") return summary(alerts, "reminders and timers");
        const tasks = current.tasks.filter((item) => !item.completedAt);
        const next = current.items.filter((item) => item.kind === "event" && !item.cancelledAt && item.at > now)
          .sort((a, b) => a.at - b.at)[0];
        const tasksText = tasks.length ? `Open tasks: ${tasks.slice(0, 3).map((item) => item.text).join("; ")}.${tasks.length > 3 ? ` Plus ${tasks.length - 3} more.` : ""}` : "Your task list is clear.";
        return `Here's your briefing. ${summary(events, "calendar events")} ${summary(alerts, "reminders and timers")} ${tasksText}${next && !events.some((item) => item.id === next.id) ? ` Next event: ${next.text} on ${DATE_TIME.format(next.at)}.` : ""}`;
      }
      case "add-task":
        if (!text) throw new AssistantError("Tell me what to add to your list.");
        insert("tasks", { text });
        return `Added ${text} to your list.`;
      case "complete-task": {
        const task = findOne(current.tasks.filter((item) => !item.completedAt), text, "open task");
        save({ ...current, tasks: current.tasks.map((item) => item.id === task.id ? { ...item, completedAt: now } : item) });
        return `Marked ${task.text} as done.`;
      }
      case "tasks": {
        const tasks = current.tasks.filter((item) => !item.completedAt);
        if (!tasks.length) return "Your task list is clear.";
        return `Still to do: ${tasks.slice(0, 8).map((item) => item.text).join("; ")}.${tasks.length > 8 ? ` Plus ${tasks.length - 8} more.` : ""}`;
      }
      case "add-note":
        if (!text) throw new AssistantError("Tell me what to write down.");
        insert("notes", { text });
        return "I saved that in your notes.";
      case "notes": {
        const notes = [...legacyNotes(), ...current.notes.map((item) => item.text)]
          .filter((item) => !text || normalized(item).includes(normalized(text))).reverse();
        if (!notes.length) return text ? `No notes matched ${text}.` : "Your notebook is empty.";
        return `Your notes: ${notes.slice(0, 4).join("; ")}.${notes.length > 4 ? ` Plus ${notes.length - 4} more.` : ""}`;
      }
      default:
        throw new AssistantError("That assistant command is unavailable.");
    }
  }

  return {
    execute(command) {
      try {
        return { ok: true, message: run(command) };
      } catch (error) {
        if (error instanceof AssistantError) return { ok: false, message: error.message };
        console.error("ULTRON assistant storage failed:", error.code || error.message);
        return { ok: false, message: "I could not access your local assistant data." };
      }
    },
    start() { running = true; tick(); },
    stop() { running = false; clearTimeout(alarm); },
    resume() { clearTimeout(alarm); tick(); },
  };
}

module.exports = { createAssistant };
