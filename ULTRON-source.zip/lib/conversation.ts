export function invitesConversation(text: string): boolean {
  return /^(?:let(?:['’]s| us)\s+(?:just\s+)?(?:talk|chat|have a conversation)|(?:can|could|shall)\s+we\s+(?:just\s+)?(?:talk|chat)|(?:i\s+(?:just\s+)?want\s+to|i\s+feel\s+like)\s+(?:talk(?:ing)?|chat(?:ting)?)|(?:biraz\s+)?(?:konuşalım|sohbet edelim))\b/iu.test(text.trim());
}
