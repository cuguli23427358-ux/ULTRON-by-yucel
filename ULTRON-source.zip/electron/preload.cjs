const { contextBridge, ipcRenderer } = require("electron");

// Future Windows-control features must be exposed here individually, after
// validation and user-confirmation rules are added in the main process.
contextBridge.exposeInMainWorld("ultronDesktop", {
  isDesktopApp: true,
  platform: process.platform,
  runAction: (action) => ipcRenderer.invoke("ultron:run-action", action),
  credentialsStatus: () => ipcRenderer.invoke("ultron:credentials-status"),
  updateCredentials: (request) => ipcRenderer.invoke("ultron:credentials-update", request),
  discardCredentialFile: () => ipcRenderer.invoke("ultron:credentials-discard-file"),
  onCredentialFile(callback) {
    const listener = () => callback();
    ipcRenderer.on("ultron:credential-file", listener);
    return () => ipcRenderer.removeListener("ultron:credential-file", listener);
  },
  onPauseVoice(callback) {
    const listener = () => callback();
    ipcRenderer.on("ultron:pause-voice", listener);
    return () => ipcRenderer.removeListener("ultron:pause-voice", listener);
  },
});
