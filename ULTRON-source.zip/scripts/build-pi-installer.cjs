const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const { createHash } = require("node:crypto");
const { spawnSync } = require("node:child_process");

const root = path.resolve(__dirname, "..");
const source = [
  "app", "components", "lib", "electron/cloud.cjs", "scripts/gateway.cjs",
  "package.json", "package-lock.json", "tsconfig.json", "next.config.ts", "README.md", "LICENSE",
];
const temporary = fs.mkdtempSync(path.join(os.tmpdir(), "ultron-pi-build-"));
const archive = path.join(temporary, "source.tar.gz");
try {
  const result = spawnSync("tar", ["-czf", archive, ...source], { cwd: root, stdio: "inherit" });
  if (result.status !== 0) throw result.error || new Error("Could not archive ULTRON source.");
  const data = fs.readFileSync(archive);
  const template = fs.readFileSync(path.join(__dirname, "pi-installer.sh"), "utf8")
    .replace(/^\uFEFF/, "").replace(/\r\n/g, "\n").replace(/@ULTRON_ARCHIVE_SHA@/, createHash("sha256").update(data).digest("hex"));
  const payload = data.toString("base64").match(/.{1,76}/g).join("\n");
  const output = path.join(root, "dist", "ULTRON-Pi-Kurulum.sh");
  fs.mkdirSync(path.dirname(output), { recursive: true });
  fs.writeFileSync(output, template.trimEnd() + "\n\n: <<'ULTRON_PAYLOAD_END'\n# ULTRON_SOURCE_ARCHIVE\n" + payload + "\nULTRON_PAYLOAD_END\n", { mode: 0o755 });
  console.log(output);
} finally {
  if (fs.existsSync(archive)) fs.unlinkSync(archive);
  fs.rmdirSync(temporary);
}
