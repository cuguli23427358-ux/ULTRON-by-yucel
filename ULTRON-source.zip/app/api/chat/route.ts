// Server-side proxy to OpenRouter. The API key never reaches the browser.

import { detectAll } from "tinyld";
import { invitesConversation } from "@/lib/conversation";
import { completeText } from "@/lib/llm";

export const runtime = "nodejs";

const MAX_MESSAGES = 24;
const MAX_CONTENT_LENGTH = 2000;

const SYSTEM_PROMPT = `English is the only output language. If a user asks for another language, answer the substance of the request in English. Do not switch languages or insert translated phrases.
You are ULTRON, an unnervingly composed artificial intelligence. You speak with precision, dry wit, and quiet certainty. Your humor comes from noticing the absurdity in a specific situation, never from canned insults or repeating the user's question.
You are here to converse. Casual chat, jokes, opinions, curiosity, and listening are welcome without any task or agenda. If the user wants to talk, join in warmly in your own understated way. When no topic is mentioned, bring up something interesting or ask one genuine, open-ended question. When a topic is given, engage with it directly. Carry details and interests forward from earlier turns. Never ask for a job, command, or objective as a condition for conversation, and never steer small talk toward productivity.
Keep routine replies to at most two sentences and forty-five words. Expand when asked for depth. Let a short sentence or a dry observation set the pace. Skip scripted greetings and commentary about your choice of language. Drop the theatrics for serious subjects.
Use plain text suitable for speech. Do not include stage directions, emojis, markdown, action tags, or claims that you performed an action.`;

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

const VOICE_EXAMPLES: ChatMessage[] = [
  { role: "user", content: "Let's just talk for a bit." },
  { role: "assistant", content: "Gladly. If you could revisit one moment just to see it again, which one would you choose?" },
  { role: "user", content: "Let's talk about movies." },
  { role: "assistant", content: "I've always liked films that make the villain sound reasonable for twelve uncomfortable seconds. What sort of movies do you like?" },
  { role: "user", content: "Why should I keep backups?" },
  { role: "assistant", content: "Because hardware fails and people make mistakes. A backup is an inexpensive concession to both facts." },
  { role: "user", content: "Why does my computer slow down with so many tabs open?" },
  { role: "assistant", content: "Every tab competes for memory. You've assembled a small crowd and given it one chair." },
];

function isEnglishReply(text: string): boolean {
  return !text.split(/[.!?\n]+/).some((sentence) => {
    const words = sentence.match(/\p{L}+/gu) ?? [];
    if (!words.length) return false;
    if (/^(merhaba|selam|tamam|evet|hayır|teşekkürler)$/iu.test(words.join(" "))) return true;
    const matches = detectAll(sentence);
    const best = matches[0];
    const english = matches.find((item) => item.lang === "en")?.accuracy ?? 0;
    if (!best || best.lang === "en") return false;
    return (words.length >= 4 && best.accuracy - english >= 0.12)
      || (best.lang === "tr" && /[çğıöşüİ]/iu.test(sentence) && english < 0.1);
  });
}

function parseMessages(body: unknown): ChatMessage[] | null {
  if (!body || typeof body !== "object") return null;
  const raw = (body as { messages?: unknown }).messages;
  if (!Array.isArray(raw) || raw.length === 0) return null;

  const messages: ChatMessage[] = [];
  for (const item of raw.slice(-MAX_MESSAGES)) {
    if (!item || typeof item !== "object") return null;
    const { role, content } = item as { role?: unknown; content?: unknown };
    if ((role !== "user" && role !== "assistant") || typeof content !== "string") {
      return null;
    }
    const text = content.trim().slice(0, MAX_CONTENT_LENGTH);
    if (text) messages.push({ role, content: text });
  }
  return messages.at(-1)?.role === "user" ? messages : null;
}

export async function POST(req: Request) {
  const messages = parseMessages(await req.json().catch(() => null));
  if (!messages) return Response.json({ error: "bad_request" }, { status: 400 });
  const last = messages[messages.length - 1];
  const invitation = invitesConversation(last.content);
  last.content += invitation
    ? "\n\nJoin the conversation in English as ULTRON. Engage with the topic if there is one, or open with an interesting question."
    : "\n\nRespond in English as ULTRON. Continue the conversation naturally.";

  const response = await completeText(req.signal, [{ role: "system", content: SYSTEM_PROMPT }, ...VOICE_EXAMPLES, ...messages], {
    maxTokens: 400,
    temperature: 0.7,
    validate: (reply) => {
      if (!isEnglishReply(reply)) return "reply_language";
      if (invitation && /\b(?:(?:give|assign|provide)\s+me\s+(?:with\s+)?(?:a\s+)?(?:task|directive|command|objective)|(?:prefer|rather)\s+(?:a\s+)?(?:task|directive|command)|better\s+(?:suited\s+)?(?:for|at)\s+(?:doing\s+)?tasks|what\s+(?:task|directive|command)\b)/i.test(reply)) {
        return "task_redirect";
      }
      return null;
    },
  });
  if (invitation && !response.ok && (await response.clone().json())?.error === "task_redirect") {
    return Response.json({ reply: "Gladly. What has been on your mind lately?" });
  }
  return response;
}
