const fs = require("node:fs");
const http = require("node:http");
const { isIP } = require("node:net");
const path = require("node:path");
const next = require("next");
const { CLOUD_ROUTES, json, validateRequest } = require("../electron/cloud.cjs");

const host = process.env.ULTRON_GATEWAY_HOST || "127.0.0.1";
const requestedPort = Number(process.env.PORT || 8080);
const quotaFile = path.resolve(process.env.ULTRON_GATEWAY_QUOTA_FILE || ".ultron-gateway/usage.json");
const totalLimit = Number(process.env.ULTRON_GATEWAY_DAILY_LIMIT || 300);
const trustProxy = process.env.ULTRON_GATEWAY_TRUST_PROXY === "1";
const perMinute = new Map();
let lastSweep = 0;
let inFlight = 0;
let usage;

function loopback(address) {
  return address === "::1" || /^127\./.test(address) || /^::ffff:127\./.test(address);
}

function sourceAddress(req) {
  const peer = req.socket.remoteAddress || "unknown";
  const header = req.headers["x-real-ip"];
  return trustProxy && loopback(peer) && typeof header === "string" && isIP(header) ? header : peer;
}

function loadUsage() {
  try {
    const state = JSON.parse(fs.readFileSync(quotaFile, "utf8"));
    if (typeof state.day !== "string" || !Number.isSafeInteger(state.total) || state.total < 0 ||
        !state.routes || Object.values(state.routes).some((count) => !Number.isSafeInteger(count) || count < 0)) {
      throw new Error("Invalid gateway quota file");
    }
    return state;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    return null;
  }
}

function reserve(req, pathname, limit) {
  const now = Date.now();
  const minute = Math.floor(now / 60_000);
  if (minute !== lastSweep) {
    perMinute.clear();
    lastSweep = minute;
  }
  const address = sourceAddress(req);
  const calls = perMinute.get(address) || 0;
  if (calls >= 24 || inFlight >= 12) return 60;

  const day = new Date(now).toISOString().slice(0, 10);
  const state = usage?.day === day ? usage : { day, total: 0, routes: {} };
  const count = state.routes[pathname] || 0;
  if (state.total >= totalLimit || count >= limit.daily) {
    return Math.ceil((Date.parse(day + "T00:00:00Z") + 86_400_000 - now) / 1000);
  }
  const nextUsage = { day, total: state.total + 1, routes: { ...state.routes, [pathname]: count + 1 } };
  fs.writeFileSync(quotaFile + ".tmp", JSON.stringify(nextUsage), { mode: 0o600 });
  fs.renameSync(quotaFile + ".tmp", quotaFile);
  usage = nextUsage;
  perMinute.set(address, calls + 1);
  return 0;
}

async function main() {
  if (!process.env.OPENROUTER_API_KEY?.trim() || !process.env.GROQ_API_KEY?.trim()) {
    throw new Error("Set OPENROUTER_API_KEY and GROQ_API_KEY on the hosting server.");
  }
  if (!Number.isSafeInteger(totalLimit) || totalLimit < 1 || !Number.isInteger(requestedPort) ||
      requestedPort < 0 || requestedPort > 65535 || (trustProxy && !loopback(host))) {
    throw new Error("Invalid gateway port, quota, or trusted-proxy configuration.");
  }
  fs.mkdirSync(path.dirname(quotaFile), { recursive: true });
  usage = loadUsage();
  let handler;
  const server = http.createServer({ requestTimeout: 30_000, headersTimeout: 10_000 }, (req, res) => {
    if (!handler) return json(res, 503, "shared_service_unavailable");
    if (req.method === "GET" && req.url === "/healthz") {
      res.writeHead(200, { "Content-Type": "application/json", "Cache-Control": "no-store" });
      return res.end('{"ok":true}');
    }
    const route = CLOUD_ROUTES.get(req.url);
    if (!route) return json(res, 404, "not_found");
    if (req.method !== "POST") return json(res, 405, "method_not_allowed", { Allow: "POST" });
    if (!validateRequest(req, req.url, route, res)) return;
    try {
      const retry = reserve(req, req.url, route);
      if (retry) return json(res, 429, "gateway_limit", { "Retry-After": String(retry) });
    } catch (error) {
      console.error("Gateway quota could not be saved:", error.code || error.name);
      return json(res, 503, "shared_service_unavailable");
    }

    inFlight++;
    res.once("close", () => { inFlight--; });
    void handler(req, res).catch(() => {
      if (!res.headersSent) json(res, 502, "shared_service_unavailable");
      else res.destroy();
    });
  });
  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(requestedPort, host, resolve);
  });
  const port = server.address().port;
  const app = next({ dev: false, dir: path.join(__dirname, ".."), hostname: host, port });
  try {
    await app.prepare();
    handler = app.getRequestHandler();
  } catch (error) {
    server.close();
    throw error;
  }
  console.log(`ULTRON gateway listening on ${host}:${port}`);
}

main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
