// Voice conversation loop: listen (Web Speech API) → ask OpenRouter via
// /api/chat → speak the reply (speechSynthesis) → listen again.

import {
  type DesktopCommand,
  type DesktopActionResult,
  isDesktopApp,
  parseDesktopIntent,
  executeDesktopAction,
} from "./desktopActions";
import { speakTok, stopTokSpeech } from "./tokSpeech";
import { assistantDateFollowUp, researchQuestion, type AssistantCommand, type ResearchSource } from "./assistantCommands";

export type VoiceState = "off" | "listening" | "thinking" | "speaking";

export interface VoiceCallbacks {
  onState(state: VoiceState): void;
  /** Live transcript of what the user is saying (final=true when committed). */
  onUserText(text: string, final: boolean): void;
  onReply(text: string): void;
  onSources?(sources: ResearchSource[]): void;
  onError(message: string): void;
}

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}

interface Interruption {
  triggered: boolean;
}

// The Web Speech recognition types are not part of lib.dom, so describe the
// small surface we use.
interface RecognitionResultLike {
  isFinal: boolean;
  0: { transcript: string };
}
interface RecognitionEventLike {
  resultIndex: number;
  results: ArrayLike<RecognitionResultLike>;
}
interface RecognitionErrorLike {
  error: string;
}
interface RecognitionLike {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  maxAlternatives: number;
  onresult: ((e: RecognitionEventLike) => void) | null;
  onerror: ((e: RecognitionErrorLike) => void) | null;
  onend: (() => void) | null;
  start(): void;
  abort(): void;
}
type RecognitionCtor = new () => RecognitionLike;

function getRecognitionCtor(): RecognitionCtor | null {
  if (typeof window === "undefined") return null;
  const w = window as unknown as {
    SpeechRecognition?: RecognitionCtor;
    webkitSpeechRecognition?: RecognitionCtor;
  };
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null;
}

class ChatError extends Error {}

const MAX_HISTORY = 20;
let microphoneOwner: VoiceAgent | null = null;
function settingsLocation(): string {
  return isDesktopApp() ? "API Keys" : ".env.local";
}

export function describeChatError(code?: string, status?: number): string {
  if (code === "missing_key") return `API KEY MISSING · SET OPENROUTER_API_KEY OR GROQ_API_KEY IN ${settingsLocation()}`;
  if (code === "upstream") {
    if (status === 401 || status === 403) return "CHAT API KEY REJECTED";
    if (status === 402) return "CHAT API OUT OF CREDITS";
    if (status === 404) return "CHAT MODEL NOT FOUND";
    if (status === 429) return "RATE LIMITED · TRY AGAIN SHORTLY";
    return "CHAT SERVICE ERROR";
  }
  if (code === "network") return "LINK FAILURE · CHAT SERVICE UNREACHABLE";
  if (code === "timeout") return "CHAT SERVICE TIMED OUT";
  if (code === "shared_service_unavailable") return "The shared ULTRON service is temporarily unavailable.";
  if (code === "gateway_limit") return "The shared service is at its limit. Try again later.";
  if (code === "reply_language") return "I could not get an English reply. Try again.";
  if (code === "incomplete_document") return "The document response was incomplete. I did not save it.";
  return "NO RESPONSE FROM MODEL";
}

export class VoiceAgent {
  private cb: VoiceCallbacks;
  private readonly lang = "en-US";
  private state: VoiceState = "off";
  private active = false;
  private turn = 0; // bumped to invalidate in-flight work
  private history: ChatMessage[] = [];
  private assistantView: "agenda" | "briefing" | "alerts" | null = null;
  private researchTopic: string | null = null;
  private interruption: Interruption | null = null;
  private recognition: RecognitionLike | null = null;
  private recorder: MediaRecorder | null = null;
  private recordingStream: MediaStream | null = null;
  private recordingTimer: number | null = null;
  private silenceTimer: number | null = null;
  private audioContext: AudioContext | null = null;
  private fetchAbort: AbortController | null = null;

  constructor(callbacks: VoiceCallbacks) {
    this.cb = callbacks;
  }

  /** Start continuous voice conversation. */
  start(): void {
    if (this.active) return;
    if (microphoneOwner && microphoneOwner !== this) {
      this.cb.onError("MICROPHONE IN USE · STOP THE OTHER VOICE MODE FIRST");
      return;
    }
    if (!isDesktopApp() && !getRecognitionCtor()) {
      this.cb.onError("SPEECH RECOGNITION UNSUPPORTED · USE CHROME/EDGE OR TYPE BELOW");
      return;
    }
    this.active = true;
    microphoneOwner = this;
    this.turn++;
    this.beginInput();
  }

  /** Stop everything: mic, in-flight request and speech. */
  stop(): void {
    this.active = false;
    if (microphoneOwner === this) microphoneOwner = null;
    this.turn++;
    this.interruption = null;
    this.killRecognition();
    this.killRecording();
    this.fetchAbort?.abort();
    this.fetchAbort = null;
    stopTokSpeech();
    this.setState("off");
  }

  /** Send a typed message (works with or without voice mode). */
  sendText(text: string): void {
    const trimmed = text.trim();
    if (!trimmed) return;
    this.interruption = null;
    this.killRecognition();
    this.killRecording();
    this.fetchAbort?.abort();
    stopTokSpeech();
    this.submitUserText(trimmed);
  }

  getState(): VoiceState {
    return this.state;
  }

  interrupt(): void {
    if (this.state !== "speaking") return;
    this.interruption = null;
    this.killRecognition();
    this.killRecording();
    stopTokSpeech();
  }

  // ——— internals ———

  private setState(state: VoiceState): void {
    if (state === this.state) return;
    this.state = state;
    this.cb.onState(state);
  }

  private submitUserText(text: string): void {
    this.cb.onUserText(text, true);
    this.cb.onSources?.([]);
    if (/^(?:wait|hold on|stop)[.!?]*$/i.test(text.trim())) {
      this.setState("off");
      if (this.active) this.beginInput();
      return;
    }
    const day = assistantDateFollowUp(text);
    const command = day && this.assistantView
      ? { type: "assistant" as const, command: { operation: this.assistantView, range: day } }
      : parseDesktopIntent(text);
    this.assistantView = null;
    if (command) {
      this.researchTopic = null;
      void this.runDesktopCommand(command);
      return;
    }
    const research = !day ? researchQuestion(text) : this.researchTopic && text;
    const previous = day ? this.researchTopic : null;
    this.researchTopic = null;
    if (research) void this.ask(text, { query: research, context: previous });
    else void this.ask(text);
  }

  private async runDesktopCommand(command: DesktopCommand): Promise<void> {
    const turn = ++this.turn;
    this.setState("thinking");
    const controller = new AbortController();
    this.fetchAbort = controller;
    let interrupted = false;
    try {
      const { message: reply, ok } = await this.executeCommand(command, controller.signal);
      if (turn !== this.turn) return;
      if (ok && command.type === "assistant") this.rememberAssistantView(command.command);
      this.cb.onReply(reply);
      this.setState("speaking");
      interrupted = await this.speakReply(reply);
    } catch (error) {
      if (turn === this.turn && !interrupted) {
        this.cb.onError(error instanceof ChatError ? error.message : "DESKTOP ACTION FAILED");
      }
    } finally {
      if (this.fetchAbort === controller) this.fetchAbort = null;
      if (turn === this.turn) {
        if (this.active) this.beginInput();
        else this.setState("off");
      }
    }
  }

  private rememberAssistantView(command: AssistantCommand): void {
    if (command.operation === "agenda" || command.operation === "alerts" || command.operation === "briefing") {
      this.assistantView = command.operation;
    }
  }

  private async speakReply(reply: string): Promise<boolean> {
    const monitor = this.active ? { triggered: false } : null;
    if (monitor) {
      this.interruption = monitor;
      if (isDesktopApp()) void this.beginDesktopListening(monitor);
      else this.beginBrowserInterruption(monitor);
    }
    try {
      await speakTok(reply);
      return monitor?.triggered ?? false;
    } finally {
      if (monitor && this.interruption === monitor && !monitor.triggered) {
        this.interruption = null;
        this.killRecording();
        this.killRecognition();
      }
    }
  }

  private beginBrowserInterruption(monitor: Interruption): void {
    const Recognition = getRecognitionCtor();
    if (!Recognition) return;
    const rec = new Recognition();
    rec.lang = this.lang;
    rec.continuous = true;
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onresult = (event) => {
      const transcript = event.results[event.resultIndex]?.[0].transcript.trim();
      const match = transcript?.match(/^(?:wait|hold on|stop)(?:[\s,.!?;:—-]+|$)(.*)$/i);
      if (!match || this.interruption !== monitor) return;
      monitor.triggered = true;
      this.interruption = null;
      this.killRecognition();
      stopTokSpeech();
      const followUp = match[1].trim();
      if (followUp) this.submitUserText(followUp);
      else this.beginInput();
    };
    this.recognition = rec;
    try {
      rec.start();
    } catch {
      this.killRecognition();
    }
  }

  private async executeCommand(command: DesktopCommand, signal: AbortSignal): Promise<DesktopActionResult> {
    if (command.type !== "write-document" && command.type !== "revise-document") {
      return executeDesktopAction(command);
    }
    if (!isDesktopApp()) return { ok: false, message: "That command requires the Windows desktop app." };

    const source = command.type === "revise-document"
      ? await executeDesktopAction({ type: "read-text-file", file: command.file })
      : null;
    if (source && (!source.ok || typeof source.text !== "string" || !source.revision)) return source;
    signal.throwIfAborted();

    const response = await fetch("/api/document", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(command.type === "write-document"
        ? { mode: "write", instruction: command.topic }
        : { mode: "edit", instruction: command.instruction, original: source?.text }),
      signal: AbortSignal.any([signal, AbortSignal.timeout(55_000)]),
    });
    const data = await response.json().catch(() => null);
    if (!response.ok || typeof data?.reply !== "string") {
      throw new ChatError(describeChatError(data?.error, data?.status));
    }
    const content = data.reply.replace(/^\x60{3}[^\n]*\n([\s\S]*?)\n\x60{3}$/, "$1");
    signal.throwIfAborted();
    if (command.type === "revise-document" && source?.revision) {
      return executeDesktopAction({ type: "update-text-file", file: command.file, revision: source.revision, content });
    }

    if (command.type === "write-document") {
      const label = command.topic.replace(/[^\p{L}\p{N} -]+/gu, " ").replace(/\s+/g, " ").trim().slice(0, 64).trim();
      const file = command.file || `ULTRON - ${label || "Document"}.txt`;
      return executeDesktopAction({ type: "create-text-file", file, content });
    }
    throw new ChatError("The document could not be read.");
  }

  private killRecognition(): void {
    const rec = this.recognition;
    this.recognition = null;
    if (!rec) return;
    rec.onresult = null;
    rec.onerror = null;
    rec.onend = null;
    try {
      rec.abort();
    } catch {
      /* already stopped */
    }
  }

  private killRecording(): void {
    if (this.recordingTimer !== null) window.clearTimeout(this.recordingTimer);
    this.recordingTimer = null;
    if (this.silenceTimer !== null) window.clearInterval(this.silenceTimer);
    this.silenceTimer = null;
    void this.audioContext?.close().catch(() => {});
    this.audioContext = null;
    const recorder = this.recorder;
    this.recorder = null;
    if (recorder) {
      recorder.onstop = null;
      recorder.onerror = null;
      if (recorder.state !== "inactive") recorder.stop();
    }
    this.recordingStream?.getTracks().forEach((track) => track.stop());
    this.recordingStream = null;
  }

  private beginInput(): void {
    if (isDesktopApp()) {
      void this.beginDesktopListening();
    } else {
      this.beginListening();
    }
  }

  private async beginDesktopListening(monitor?: Interruption): Promise<void> {
    if (!this.active || this.recorder) return;
    const listenTurn = this.turn;
    if (!monitor) this.setState("listening");

    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
      });
    } catch {
      if (!monitor && this.active && listenTurn === this.turn) {
        this.cb.onError("MICROPHONE ACCESS DENIED");
        this.stop();
      }
      return;
    }
    if (!this.active || listenTurn !== this.turn || (monitor && this.interruption !== monitor)) {
      stream.getTracks().forEach((track) => track.stop());
      return;
    }

    const chunks: BlobPart[] = [];
    this.recordingStream = stream;
    let recorder: MediaRecorder;
    try {
      recorder = new MediaRecorder(stream, { mimeType: "audio/webm;codecs=opus" });
      this.recorder = recorder;
      recorder.start();
    } catch {
      this.killRecording();
      if (monitor) return;
      this.cb.onError("MICROPHONE RECORDING UNAVAILABLE");
      this.stop();
      return;
    }
    recorder.onerror = () => {
      if (monitor && !monitor.triggered) {
        this.killRecording();
        return;
      }
      this.cb.onError("MICROPHONE RECORDING FAILED");
      this.stop();
    };
    recorder.ondataavailable = (event) => {
      if (event.data.size) chunks.push(event.data);
    };
    recorder.onstop = () => {
      if (this.recorder !== recorder) return;
      this.killRecording();
      if (!this.active || listenTurn !== this.turn) return;
      if (monitor) {
        if (!monitor.triggered) return;
        this.interruption = null;
      }
      if (chunks.length) {
        this.setState("thinking");
        void this.transcribeDesktopAudio(new Blob(chunks, { type: "audio/webm" }), listenTurn, Boolean(monitor));
      } else {
        this.beginInput();
      }
    };
    // Let a longer instruction finish without delaying short commands.
    this.stopAfterSpeech(stream, recorder, monitor);
    if (!monitor) this.armRecording(recorder, 14_000);
  }

  private armRecording(recorder: MediaRecorder, limit: number): void {
    this.recordingTimer = window.setTimeout(() => {
      if (recorder.state !== "inactive") recorder.stop();
    }, limit);
  }

  private stopAfterSpeech(stream: MediaStream, recorder: MediaRecorder, monitor?: Interruption): void {
    try {
      const context = new AudioContext();
      this.audioContext = context;
      const analyser = context.createAnalyser();
      analyser.fftSize = 1024;
      context.createMediaStreamSource(stream).connect(analyser);
      void context.resume().catch(() => {});
      const samples = new Float32Array(analyser.fftSize);
      let speechFrames = 0;
      let lastSpeech = 0;
      this.silenceTimer = window.setInterval(() => {
        if (context.state !== "running" || recorder.state !== "recording") return;
        analyser.getFloatTimeDomainData(samples);
        const energy = samples.reduce((sum, sample) => sum + sample * sample, 0) / samples.length;
        const threshold = monitor && !monitor.triggered ? 0.00055 : 0.00015;
        if (energy >= threshold) {
          speechFrames++;
          lastSpeech = performance.now();
          if (monitor && !monitor.triggered && speechFrames >= 2) {
            monitor.triggered = true;
            this.setState("listening");
            this.armRecording(recorder, 8_000);
            stopTokSpeech();
          }
        } else if (monitor && !monitor.triggered) {
          speechFrames = 0;
        } else if (speechFrames >= (monitor ? 2 : 3) && performance.now() - lastSpeech >= 1_250) {
          recorder.stop();
        }
      }, 100);
    } catch {
      // Recording still finishes if input analysis is unavailable.
    }
  }

  private async transcribeDesktopAudio(audio: Blob, listenTurn: number, interrupted = false): Promise<void> {
    const controller = new AbortController();
    this.fetchAbort = controller;
    try {
      const body = new FormData();
      body.append("audio", audio, "voice.webm");
      const response = await fetch("/api/transcribe", {
        method: "POST", body,
        signal: AbortSignal.any([controller.signal, AbortSignal.timeout(20_000)]),
      });
      const data = (await response.json().catch(() => null)) as {
        text?: string;
        error?: string;
        status?: number;
      } | null;
      if (!response.ok || typeof data?.text !== "string") {
        if (data?.error === "gateway_limit" || data?.error === "shared_service_unavailable") {
          throw new ChatError(describeChatError(data.error));
        }
        if (data?.error === "missing_key") throw new ChatError(`GROQ API KEY MISSING · SET GROQ_API_KEY IN ${settingsLocation()}`);
        if (data?.status === 401 || data?.status === 403) throw new ChatError("GROQ API KEY REJECTED");
        if (data?.error === "upstream" && data.status === 429) throw new ChatError("GROQ FREE LIMIT REACHED · TRY AGAIN LATER");
        throw new ChatError("GROQ SPEECH SERVICE ERROR");
      }
      if (!this.active || listenTurn !== this.turn) return;
      const transcript = data.text.trim();
      const text = interrupted
        ? transcript.match(/^(?:wait|hold on|stop)(?:[\s,.!?;:—-]+|$)(.*)$/i)?.[1].trim() ?? ""
        : transcript;
      if (text) {
        this.submitUserText(text);
      } else {
        this.beginInput();
      }
    } catch (error) {
      if (!this.active || listenTurn !== this.turn) return;
      this.cb.onError(error instanceof ChatError ? error.message : "SPEECH TRANSCRIPTION FAILED");
      this.stop();
    } finally {
      if (this.fetchAbort === controller) this.fetchAbort = null;
    }
  }

  private beginListening(): void {
    if (!this.active) return;
    const Ctor = getRecognitionCtor();
    if (!Ctor) return;

    const rec = new Ctor();
    rec.lang = this.lang;
    rec.continuous = false;
    rec.interimResults = true;
    rec.maxAlternatives = 1;

    let finalText = "";

    rec.onresult = (e) => {
      let interim = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const result = e.results[i];
        if (result.isFinal) finalText += result[0].transcript;
        else interim += result[0].transcript;
      }
      const live = (finalText + interim).trim();
      if (live) this.cb.onUserText(live, false);
    };

    rec.onerror = (e) => {
      // "no-speech" / "aborted" are normal; onend restarts listening.
      if (e.error === "no-speech" || e.error === "aborted") return;
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        this.cb.onError("MICROPHONE ACCESS DENIED");
      } else if (e.error === "audio-capture") {
        this.cb.onError("NO MICROPHONE FOUND");
      } else if (e.error === "network") {
        this.cb.onError("SPEECH SERVICE UNREACHABLE");
      } else {
        this.cb.onError("SPEECH RECOGNITION ERROR");
      }
      this.stop();
    };

    rec.onend = () => {
      if (this.recognition !== rec) return; // superseded or stopped
      this.recognition = null;
      const text = finalText.trim();
      if (text && this.active) {
        this.submitUserText(text);
        return;
      }
      // Silence timeout — keep the mic open while conversation mode is on.
      window.setTimeout(() => {
        if (this.active && this.state === "listening" && !this.recognition) {
          this.beginListening();
        }
      }, 250);
    };

    this.recognition = rec;
    this.setState("listening");
    try {
      rec.start();
    } catch {
      this.cb.onError("MICROPHONE COULD NOT START");
      this.stop();
    }
  }

  private async ask(text: string, research?: { query: string; context: string | null }): Promise<void> {
    const turn = ++this.turn;
    const messages = [...this.history, { role: "user" as const, content: text }];
    this.setState("thinking");

    const controller = new AbortController();
    this.fetchAbort = controller;
    let interrupted = false;

    try {
      const res = await fetch(research ? "/api/research" : "/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(research ?? { messages }),
        signal: AbortSignal.any([controller.signal, AbortSignal.timeout(35_000)]),
      });
      const data = (await res.json().catch(() => null)) as {
        reply?: string;
        sources?: ResearchSource[];
        error?: string;
        status?: number;
      } | null;

      if (turn !== this.turn) return;
      if (!res.ok || !data?.reply) {
        if (data?.error === "research_key") throw new ChatError(`Web research requires OPENROUTER_API_KEY in ${settingsLocation()}.`);
        if (data?.error === "research_unverified") throw new ChatError("I couldn't verify an answer from web sources.");
        throw new ChatError(describeChatError(data?.error, data?.status));
      }

      this.history = [...messages, { role: "assistant" as const, content: data.reply }].slice(-MAX_HISTORY);
      if (research) {
        this.researchTopic = research.context ?? research.query;
        this.cb.onSources?.(data.sources ?? []);
      }
      this.cb.onReply(data.reply);

      this.setState("speaking");
      interrupted = await this.speakReply(data.reply);
      if (turn !== this.turn) return;
    } catch (err) {
      if (turn !== this.turn || (err instanceof DOMException && err.name === "AbortError")) {
        return;
      }
      this.cb.onError(err instanceof ChatError ? err.message : "LINK FAILURE");
    } finally {
      if (turn === this.turn && !interrupted) {
        this.fetchAbort = null;
        if (this.active) this.beginInput();
        else this.setState("off");
      }
    }
  }
}
