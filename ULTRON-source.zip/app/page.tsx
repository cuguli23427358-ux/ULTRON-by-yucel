import JarvisOrb from "@/components/JarvisOrb";

export default function Home() {
  return (
    <main>
      <JarvisOrb />
    </main>
  );
}
